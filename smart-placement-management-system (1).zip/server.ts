import express, { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

// Parse JSON request body with robust error handling for malformed JSON
app.use(express.json({
  limit: '2mb',
  verify: (req: any, _res, buf) => {
    req.rawBody = buf.toString();
  }
}));

// Fallback for JSON body parse error: return JSON, NEVER HTML!
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  if (err instanceof SyntaxError && 'body' in err) {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    return res.status(400).json({
      success: false,
      message: 'Invalid JSON payload sent in request body.',
      data: null
    });
  }
  next(err);
});

// Middleware to ensure all /api routes have JSON content type
app.use('/api', (req: Request, res: Response, next: NextFunction) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  // Disable caching for auth and dynamic data to prevent stale account switching data
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

// Database storage structure (SQLite compatible JSON store with atomic file writes)
const DB_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DB_DIR, 'placement_system.db.json');

if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

interface DatabaseSchema {
  users: Array<{
    id: number;
    email: string;
    password_hash: string;
    salt: string;
    role: 'student' | 'company' | 'admin';
    name: string;
    created_at: string;
  }>;
  students: Array<{
    user_id: number;
    name: string;
    email: string;
    phone: string;
    branch: string;
    semester: number;
    cgpa: number;
    skills: string[];
    academic_info: {
      tenth_percentage: number;
      twelfth_percentage: number;
      backlogs: number;
      bio: string;
    };
    resume_url?: string;
    updated_at: string;
  }>;
  companies: Array<{
    user_id: number;
    company_name: string;
    email: string;
    phone: string;
    website: string;
    location: string;
    industry: string;
    description: string;
    updated_at: string;
  }>;
  admins: Array<{
    user_id: number;
    name: string;
    email: string;
    designation: string;
    department: string;
    phone: string;
    updated_at: string;
  }>;
  jobs: Array<{
    id: number;
    company_id: number;
    company_name: string;
    title: string;
    role: string;
    package_lpa: number;
    cgpa_cutoff: number;
    eligible_branches: string[];
    required_skills: string[];
    location: string;
    deadline: string;
    description: string;
    status: 'active' | 'closed';
    created_at: string;
  }>;
  applications: Array<{
    id: number;
    job_id: number;
    student_id: number;
    student_name: string;
    student_branch: string;
    student_cgpa: number;
    student_skills: string[];
    status: 'applied' | 'shortlisted' | 'interview' | 'offered' | 'rejected';
    applied_at: string;
    updated_at: string;
    notes?: string;
  }>;
  sessions: Array<{
    token: string;
    user_id: number;
    role: 'student' | 'company' | 'admin';
    expires_at: number;
    created_at: string;
  }>;
  audit_logs: Array<{
    id: number;
    user_id: number;
    email: string;
    action: string;
    timestamp: string;
    details?: string;
  }>;
}

function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
}

function generateInitialSeed(): DatabaseSchema {
  const salt = crypto.randomBytes(16).toString('hex');
  const demoPassword = 'password123';
  const hashedPassword = hashPassword(demoPassword, salt);

  return {
    users: [
      {
        id: 101,
        email: 'rahul.sharma@campus.edu',
        password_hash: hashedPassword,
        salt,
        role: 'student',
        name: 'Rahul Sharma',
        created_at: new Date('2026-01-10T10:00:00Z').toISOString()
      },
      {
        id: 102,
        email: 'ananya.iyer@campus.edu',
        password_hash: hashedPassword,
        salt,
        role: 'student',
        name: 'Ananya Iyer',
        created_at: new Date('2026-01-12T11:00:00Z').toISOString()
      },
      {
        id: 103,
        email: 'vikram.patel@campus.edu',
        password_hash: hashedPassword,
        salt,
        role: 'student',
        name: 'Vikram Patel',
        created_at: new Date('2026-01-14T09:30:00Z').toISOString()
      },
      {
        id: 201,
        email: 'recruiting@google.com',
        password_hash: hashedPassword,
        salt,
        role: 'company',
        name: 'Google India',
        created_at: new Date('2026-01-05T08:00:00Z').toISOString()
      },
      {
        id: 202,
        email: 'campus@microsoft.com',
        password_hash: hashedPassword,
        salt,
        role: 'company',
        name: 'Microsoft IDC',
        created_at: new Date('2026-01-06T08:00:00Z').toISOString()
      },
      {
        id: 301,
        email: 'admin.placement@campus.edu',
        password_hash: hashedPassword,
        salt,
        role: 'admin',
        name: 'Prof. K. V. Verma',
        created_at: new Date('2026-01-01T08:00:00Z').toISOString()
      }
    ],
    students: [
      {
        user_id: 101,
        name: 'Rahul Sharma',
        email: 'rahul.sharma@campus.edu',
        phone: '+91 98765 43210',
        branch: 'Computer Science and Engineering',
        semester: 8,
        cgpa: 9.15,
        skills: ['C++', 'Python', 'React', 'Data Structures', 'SQL', 'Algorithms'],
        academic_info: {
          tenth_percentage: 95.4,
          twelfth_percentage: 93.8,
          backlogs: 0,
          bio: 'Passionate software engineering undergraduate specializing in algorithms, distributed systems, and modern web architectures.'
        },
        resume_url: 'https://example.com/resumes/rahul-sharma.pdf',
        updated_at: new Date().toISOString()
      },
      {
        user_id: 102,
        name: 'Ananya Iyer',
        email: 'ananya.iyer@campus.edu',
        phone: '+91 98451 23456',
        branch: 'Electronics and Communication',
        semester: 8,
        cgpa: 8.72,
        skills: ['Embedded C', 'Python', 'IoT', 'MATLAB', 'VLSI', 'Machine Learning'],
        academic_info: {
          tenth_percentage: 96.0,
          twelfth_percentage: 94.5,
          backlogs: 0,
          bio: 'ECE senior with strong fundamentals in hardware-software co-design, IoT edge computation, and Python data pipelines.'
        },
        resume_url: 'https://example.com/resumes/ananya-iyer.pdf',
        updated_at: new Date().toISOString()
      },
      {
        user_id: 103,
        name: 'Vikram Patel',
        email: 'vikram.patel@campus.edu',
        phone: '+91 97123 45678',
        branch: 'Information Technology',
        semester: 8,
        cgpa: 7.85,
        skills: ['Java', 'Spring Boot', 'SQL', 'AWS', 'Docker', 'RESTful APIs'],
        academic_info: {
          tenth_percentage: 88.0,
          twelfth_percentage: 86.2,
          backlogs: 0,
          bio: 'Backend enthusiast focused on microservices, enterprise Java applications, and cloud containerization.'
        },
        resume_url: 'https://example.com/resumes/vikram-patel.pdf',
        updated_at: new Date().toISOString()
      }
    ],
    companies: [
      {
        user_id: 201,
        company_name: 'Google India',
        email: 'recruiting@google.com',
        phone: '+91 80 6721 8000',
        website: 'https://careers.google.com',
        location: 'Bengaluru / Hyderabad',
        industry: 'Information Technology & Cloud Services',
        description: 'Google’s mission is to organize the world’s information and make it universally accessible and useful.',
        updated_at: new Date().toISOString()
      },
      {
        user_id: 202,
        company_name: 'Microsoft IDC',
        email: 'campus@microsoft.com',
        phone: '+91 40 6695 0000',
        website: 'https://careers.microsoft.com',
        location: 'Hyderabad / Noida / Bengaluru',
        industry: 'Enterprise Software & Cloud Platforms',
        description: 'Empowering every person and every organization on the planet to achieve more.',
        updated_at: new Date().toISOString()
      }
    ],
    admins: [
      {
        user_id: 301,
        name: 'Prof. K. V. Verma',
        email: 'admin.placement@campus.edu',
        designation: 'Head of Placement & Corporate Relations',
        department: 'Central Placement Cell',
        phone: '+91 11 2659 1000',
        updated_at: new Date().toISOString()
      }
    ],
    jobs: [
      {
        id: 1,
        company_id: 201,
        company_name: 'Google India',
        title: 'Software Engineer - Campus Graduate 2026',
        role: 'Software Development Engineer',
        package_lpa: 32.5,
        cgpa_cutoff: 8.5,
        eligible_branches: ['Computer Science and Engineering', 'Information Technology', 'Electronics and Communication'],
        required_skills: ['Algorithms', 'Data Structures', 'C++', 'Python'],
        location: 'Bengaluru / Hyderabad',
        deadline: '2026-12-15',
        description: 'Build large-scale high-throughput systems, cloud microservices, and AI products used by billions of users worldwide.',
        status: 'active',
        created_at: new Date('2026-02-01').toISOString()
      },
      {
        id: 2,
        company_id: 202,
        company_name: 'Microsoft IDC',
        title: 'Software Engineer (Azure & Cloud Infrastructure)',
        role: 'Full Stack & Cloud Systems Engineer',
        package_lpa: 28.0,
        cgpa_cutoff: 8.0,
        eligible_branches: ['Computer Science and Engineering', 'Information Technology'],
        required_skills: ['Data Structures', 'Java', 'C++', 'SQL', 'Algorithms'],
        location: 'Hyderabad / Bengaluru',
        deadline: '2026-12-20',
        description: 'Work on Azure Core infrastructure, distributed databases, developer tooling, and enterprise-grade resilience.',
        status: 'active',
        created_at: new Date('2026-02-05').toISOString()
      },
      {
        id: 3,
        company_id: 201,
        company_name: 'Google India',
        title: 'Hardware & Silicon Engineering Associate',
        role: 'Silicon Systems Engineer',
        package_lpa: 26.0,
        cgpa_cutoff: 8.2,
        eligible_branches: ['Electronics and Communication', 'Electrical Engineering'],
        required_skills: ['Embedded C', 'VLSI', 'MATLAB', 'Python'],
        location: 'Bengaluru',
        deadline: '2026-12-25',
        description: 'Participate in ASIC verification, custom hardware accelerators for machine learning, and board bring-up.',
        status: 'active',
        created_at: new Date('2026-02-10').toISOString()
      }
    ],
    applications: [
      {
        id: 1,
        job_id: 1,
        student_id: 101,
        student_name: 'Rahul Sharma',
        student_branch: 'Computer Science and Engineering',
        student_cgpa: 9.15,
        student_skills: ['C++', 'Python', 'React', 'Data Structures', 'SQL', 'Algorithms'],
        status: 'shortlisted',
        applied_at: new Date('2026-02-02T10:15:00Z').toISOString(),
        updated_at: new Date('2026-02-04T14:20:00Z').toISOString(),
        notes: 'Top scorer in online algorithmic test. Ranked 1 in campus Max-Heap candidate pool.'
      },
      {
        id: 2,
        job_id: 2,
        student_id: 101,
        student_name: 'Rahul Sharma',
        student_branch: 'Computer Science and Engineering',
        student_cgpa: 9.15,
        student_skills: ['C++', 'Python', 'React', 'Data Structures', 'SQL', 'Algorithms'],
        status: 'applied',
        applied_at: new Date('2026-02-06T11:00:00Z').toISOString(),
        updated_at: new Date('2026-02-06T11:00:00Z').toISOString()
      },
      {
        id: 3,
        job_id: 3,
        student_id: 102,
        student_name: 'Ananya Iyer',
        student_branch: 'Electronics and Communication',
        student_cgpa: 8.72,
        student_skills: ['Embedded C', 'Python', 'IoT', 'MATLAB', 'VLSI', 'Machine Learning'],
        status: 'interview',
        applied_at: new Date('2026-02-11T12:00:00Z').toISOString(),
        updated_at: new Date('2026-02-13T16:30:00Z').toISOString(),
        notes: 'Interview scheduled for ASIC design verification round.'
      }
    ],
    sessions: [],
    audit_logs: [
      {
        id: 1,
        user_id: 301,
        email: 'admin.placement@campus.edu',
        action: 'SYSTEM_BOOTSTRAP',
        timestamp: new Date().toISOString(),
        details: 'Placement database initialized with sample drives, candidates, and ADS engine.'
      }
    ]
  };
}

// Database helper functions with atomic write guarantee
let dbCache: DatabaseSchema | null = null;

function getDatabase(): DatabaseSchema {
  if (dbCache) return dbCache;
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      dbCache = JSON.parse(raw);
      return dbCache!;
    }
  } catch (err) {
    console.error('Error reading database file, regenerating clean state:', err);
  }
  dbCache = generateInitialSeed();
  saveDatabase(dbCache);
  return dbCache;
}

function saveDatabase(data: DatabaseSchema): void {
  dbCache = data;
  const tempPath = `${DB_FILE}.${Date.now()}.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tempPath, DB_FILE);
}

// Standard response helpers to guarantee consistent JSON structure
function sendSuccess(res: Response, message: string, data: any = null, status = 200) {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  return res.status(status).json({
    success: true,
    message,
    data
  });
}

function sendError(res: Response, message: string, status = 400, data: any = null) {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  return res.status(status).json({
    success: false,
    message,
    data
  });
}

// Authentication & Session Middleware
function authenticateSession(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  let token = '';

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7).trim();
  } else if (req.headers['x-session-token']) {
    token = String(req.headers['x-session-token']).trim();
  }

  if (!token) {
    return sendError(res, 'Authentication required: No valid session token provided.', 401);
  }

  const db = getDatabase();
  const now = Date.now();
  const session = db.sessions.find(s => s.token === token);

  if (!session) {
    return sendError(res, 'Session invalid or expired. Please sign in again.', 401);
  }

  if (session.expires_at < now) {
    // Purge expired session
    db.sessions = db.sessions.filter(s => s.token !== token);
    saveDatabase(db);
    return sendError(res, 'Session expired. Please sign in again.', 401);
  }

  const user = db.users.find(u => u.id === session.user_id);
  if (!user) {
    return sendError(res, 'User record not found for this active session.', 401);
  }

  (req as any).user = user;
  (req as any).session = session;
  next();
}

// ADS: Priority Queue / Max-Heap for Student Ranking
interface HeapNode {
  student_id: number;
  student_name: string;
  branch: string;
  cgpa: number;
  matched_skills: string[];
  missing_skills: string[];
  composite_score: number;
  status: string;
  application_id: number;
}

class MaxHeapRanker {
  private heap: HeapNode[] = [];

  public insert(node: HeapNode) {
    this.heap.push(node);
    this.bubbleUp(this.heap.length - 1);
  }

  public extractMax(): HeapNode | null {
    if (this.heap.length === 0) return null;
    const max = this.heap[0];
    const end = this.heap.pop()!;
    if (this.heap.length > 0) {
      this.heap[0] = end;
      this.sinkDown(0);
    }
    return max;
  }

  public getRankedList(): HeapNode[] {
    const copy = [...this.heap];
    const result: HeapNode[] = [];
    const tempHeap = new MaxHeapRanker();
    for (const item of copy) {
      tempHeap.insert(item);
    }
    while (tempHeap.heap.length > 0) {
      const item = tempHeap.extractMax();
      if (item) result.push(item);
    }
    return result;
  }

  private bubbleUp(n: number) {
    const element = this.heap[n];
    while (n > 0) {
      const parentN = Math.floor((n - 1) / 2);
      const parent = this.heap[parentN];
      if (element.composite_score <= parent.composite_score) break;
      this.heap[parentN] = element;
      this.heap[n] = parent;
      n = parentN;
    }
  }

  private sinkDown(n: number) {
    const length = this.heap.length;
    const element = this.heap[n];
    while (true) {
      let child2N = (n + 1) * 2;
      let child1N = child2N - 1;
      let swap: number | null = null;

      if (child1N < length) {
        const child1 = this.heap[child1N];
        if (child1.composite_score > element.composite_score) {
          swap = child1N;
        }
      }

      if (child2N < length) {
        const child2 = this.heap[child2N];
        if (
          (swap === null && child2.composite_score > element.composite_score) ||
          (swap !== null && child2.composite_score > this.heap[swap].composite_score)
        ) {
          swap = child2N;
        }
      }

      if (swap === null) break;
      this.heap[n] = this.heap[swap];
      this.heap[swap] = element;
      n = swap;
    }
  }
}

// -------------------------------------------------------------
// AUTHENTICATION API ENDPOINTS
// -------------------------------------------------------------

// POST /api/auth/register
app.post('/api/auth/register', (req: Request, res: Response) => {
  try {
    const { email, password, role, name, phone, branch, cgpa, semester, company_name } = req.body;

    if (!email || !password || !role) {
      return sendError(res, 'Email, password, and role are required fields.', 400);
    }

    if (!['student', 'company', 'admin'].includes(role)) {
      return sendError(res, 'Invalid role specified. Must be student, company, or admin.', 400);
    }

    if (password.length < 6) {
      return sendError(res, 'Password must be at least 6 characters long.', 400);
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return sendError(res, 'Invalid email format.', 400);
    }

    const db = getDatabase();
    const existing = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      return sendError(res, 'An account with this email address already exists.', 409);
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const password_hash = hashPassword(password, salt);
    const newId = (db.users.reduce((max, u) => Math.max(max, u.id), 100)) + 1;
    const nowIso = new Date().toISOString();

    const displayName = role === 'company' ? (company_name || name || 'New Enterprise') : (name || 'New User');

    const newUser = {
      id: newId,
      email: email.trim().toLowerCase(),
      password_hash,
      salt,
      role: role as 'student' | 'company' | 'admin',
      name: displayName,
      created_at: nowIso
    };

    db.users.push(newUser);

    if (role === 'student') {
      db.students.push({
        user_id: newId,
        name: displayName,
        email: email.trim().toLowerCase(),
        phone: phone || '',
        branch: branch || 'Computer Science and Engineering',
        semester: Number(semester) || 8,
        cgpa: Number(cgpa) || 7.5,
        skills: ['C++', 'Python', 'Data Structures'],
        academic_info: {
          tenth_percentage: 85,
          twelfth_percentage: 85,
          backlogs: 0,
          bio: 'Registered student ready for campus placement opportunities.'
        },
        updated_at: nowIso
      });
    } else if (role === 'company') {
      db.companies.push({
        user_id: newId,
        company_name: displayName,
        email: email.trim().toLowerCase(),
        phone: phone || '',
        website: 'https://company.example.com',
        location: 'National / Hybrid',
        industry: 'Information Technology',
        description: 'Leading organization recruiting campus talent.',
        updated_at: nowIso
      });
    } else if (role === 'admin') {
      db.admins.push({
        user_id: newId,
        name: displayName,
        email: email.trim().toLowerCase(),
        designation: 'Placement Officer',
        department: 'Career & Placement Office',
        phone: phone || '',
        updated_at: nowIso
      });
    }

    // Auto-create session token for seamless initial entry
    const token = crypto.randomBytes(32).toString('hex');
    const expires_at = Date.now() + 24 * 60 * 60 * 1000;
    db.sessions.push({
      token,
      user_id: newId,
      role: role as 'student' | 'company' | 'admin',
      expires_at,
      created_at: nowIso
    });

    db.audit_logs.push({
      id: db.audit_logs.length + 1,
      user_id: newId,
      email: newUser.email,
      action: 'REGISTER_SUCCESS',
      timestamp: nowIso,
      details: `Registered as ${role}`
    });

    saveDatabase(db);

    return sendSuccess(res, 'Account created successfully.', {
      token,
      user: {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        role: newUser.role,
        created_at: newUser.created_at
      }
    }, 201);
  } catch (err: any) {
    return sendError(res, `Failed to register account: ${err.message}`, 500);
  }
});

// POST /api/auth/login
app.post('/api/auth/login', (req: Request, res: Response) => {
  try {
    const { email, password, role } = req.body;

    if (!email || !password) {
      return sendError(res, 'Email and password are required.', 400);
    }

    const db = getDatabase();
    const user = db.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());

    if (!user) {
      return sendError(res, 'Invalid email or password.', 401);
    }

    // Check role if specified
    if (role && user.role !== role) {
      return sendError(res, `This account is registered as a ${user.role}, not as a ${role}. Please select ${user.role} or check your credentials.`, 403);
    }

    const computedHash = hashPassword(password, user.salt);
    if (computedHash !== user.password_hash) {
      return sendError(res, 'Invalid email or password.', 401);
    }

    // Generate new secure session token
    const token = crypto.randomBytes(32).toString('hex');
    const expires_at = Date.now() + 24 * 60 * 60 * 1000;
    const nowIso = new Date().toISOString();

    // Clean up any stale sessions for this user older than expiration
    db.sessions = db.sessions.filter(s => s.expires_at > Date.now());

    db.sessions.push({
      token,
      user_id: user.id,
      role: user.role,
      expires_at,
      created_at: nowIso
    });

    db.audit_logs.push({
      id: db.audit_logs.length + 1,
      user_id: user.id,
      email: user.email,
      action: 'LOGIN_SUCCESS',
      timestamp: nowIso,
      details: `Session initiated for role ${user.role}`
    });

    saveDatabase(db);

    // Fetch profile data tailored to role
    let profileData: any = null;
    if (user.role === 'student') {
      profileData = db.students.find(s => s.user_id === user.id) || null;
    } else if (user.role === 'company') {
      profileData = db.companies.find(c => c.user_id === user.id) || null;
    } else if (user.role === 'admin') {
      profileData = db.admins.find(a => a.user_id === user.id) || null;
    }

    return sendSuccess(res, 'Login successful', {
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        created_at: user.created_at
      },
      profile: profileData
    });
  } catch (err: any) {
    return sendError(res, `Authentication error: ${err.message}`, 500);
  }
});

// POST /api/auth/logout
app.post('/api/auth/logout', (req: Request, res: Response) => {
  try {
    const authHeader = req.headers.authorization;
    let token = '';

    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.substring(7).trim();
    } else if (req.headers['x-session-token']) {
      token = String(req.headers['x-session-token']).trim();
    }

    const db = getDatabase();
    if (token) {
      const activeSession = db.sessions.find(s => s.token === token);
      if (activeSession) {
        db.audit_logs.push({
          id: db.audit_logs.length + 1,
          user_id: activeSession.user_id,
          email: '',
          action: 'LOGOUT_SUCCESS',
          timestamp: new Date().toISOString(),
          details: 'Session securely terminated'
        });
      }
      db.sessions = db.sessions.filter(s => s.token !== token);
      saveDatabase(db);
    }

    // Always respond with explicit valid JSON, NEVER empty 204 or HTML!
    return sendSuccess(res, 'Signed out successfully. Session invalidated.', {
      logged_out: true
    });
  } catch (err: any) {
    return sendError(res, `Logout error: ${err.message}`, 500);
  }
});

// GET /api/auth/session
app.get('/api/auth/session', authenticateSession, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const db = getDatabase();

    let profile: any = null;
    if (user.role === 'student') {
      profile = db.students.find(s => s.user_id === user.id) || null;
    } else if (user.role === 'company') {
      profile = db.companies.find(c => c.user_id === user.id) || null;
    } else if (user.role === 'admin') {
      profile = db.admins.find(a => a.user_id === user.id) || null;
    }

    return sendSuccess(res, 'Session is active and valid.', {
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        created_at: user.created_at
      },
      profile
    });
  } catch (err: any) {
    return sendError(res, `Failed to retrieve session: ${err.message}`, 500);
  }
});

// -------------------------------------------------------------
// PROFILE EDITING ENDPOINTS (STUDENT, COMPANY, ADMIN)
// -------------------------------------------------------------

// PUT /api/student/profile
app.put('/api/student/profile', authenticateSession, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (user.role !== 'student') {
      return sendError(res, 'Unauthorized: Only students can edit a student profile.', 403);
    }

    const { name, email, phone, branch, semester, cgpa, skills, academic_info } = req.body;

    if (!name || !email) {
      return sendError(res, 'Name and email are required fields.', 400);
    }

    const numCgpa = Number(cgpa);
    if (isNaN(numCgpa) || numCgpa < 0 || numCgpa > 10) {
      return sendError(res, 'CGPA must be a valid number between 0.0 and 10.0.', 400);
    }

    const numSemester = Number(semester);
    if (isNaN(numSemester) || numSemester < 1 || numSemester > 10) {
      return sendError(res, 'Semester must be a valid number between 1 and 10.', 400);
    }

    const db = getDatabase();

    // Check email uniqueness if changed
    const emailConflict = db.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase() && u.id !== user.id);
    if (emailConflict) {
      return sendError(res, 'Another account is already using this email address.', 409);
    }

    // Update user table
    const userIndex = db.users.findIndex(u => u.id === user.id);
    if (userIndex !== -1) {
      db.users[userIndex].name = name.trim();
      db.users[userIndex].email = email.trim().toLowerCase();
    }

    // Update student table
    let studentIndex = db.students.findIndex(s => s.user_id === user.id);
    const nowIso = new Date().toISOString();

    const cleanSkills = Array.isArray(skills)
      ? skills.map(s => String(s).trim()).filter(Boolean)
      : (typeof skills === 'string' ? skills.split(',').map(s => s.trim()).filter(Boolean) : []);

    const updatedStudent = {
      user_id: user.id,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone ? String(phone).trim() : '',
      branch: branch ? String(branch).trim() : 'Computer Science and Engineering',
      semester: numSemester,
      cgpa: numCgpa,
      skills: cleanSkills,
      academic_info: {
        tenth_percentage: Number(academic_info?.tenth_percentage) || 85,
        twelfth_percentage: Number(academic_info?.twelfth_percentage) || 85,
        backlogs: Number(academic_info?.backlogs) || 0,
        bio: academic_info?.bio ? String(academic_info.bio).trim() : ''
      },
      updated_at: nowIso
    };

    if (studentIndex !== -1) {
      db.students[studentIndex] = updatedStudent;
    } else {
      db.students.push(updatedStudent);
    }

    // Also sync student name and cgpa across all their past applications
    db.applications.forEach(app => {
      if (app.student_id === user.id) {
        app.student_name = updatedStudent.name;
        app.student_branch = updatedStudent.branch;
        app.student_cgpa = updatedStudent.cgpa;
        app.student_skills = updatedStudent.skills;
      }
    });

    saveDatabase(db);

    return sendSuccess(res, 'Student profile updated successfully.', updatedStudent);
  } catch (err: any) {
    return sendError(res, `Failed to update student profile: ${err.message}`, 500);
  }
});

// PUT /api/company/profile
app.put('/api/company/profile', authenticateSession, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (user.role !== 'company') {
      return sendError(res, 'Unauthorized: Only company accounts can update company profiles.', 403);
    }

    const { company_name, email, phone, website, location, industry, description } = req.body;

    if (!company_name || !email) {
      return sendError(res, 'Company name and email are required.', 400);
    }

    const db = getDatabase();

    // Check email uniqueness if changed
    const emailConflict = db.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase() && u.id !== user.id);
    if (emailConflict) {
      return sendError(res, 'Another account is already using this email address.', 409);
    }

    // Update user table
    const userIndex = db.users.findIndex(u => u.id === user.id);
    if (userIndex !== -1) {
      db.users[userIndex].name = company_name.trim();
      db.users[userIndex].email = email.trim().toLowerCase();
    }

    let companyIndex = db.companies.findIndex(c => c.user_id === user.id);
    const nowIso = new Date().toISOString();

    const updatedCompany = {
      user_id: user.id,
      company_name: company_name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone ? String(phone).trim() : '',
      website: website ? String(website).trim() : '',
      location: location ? String(location).trim() : '',
      industry: industry ? String(industry).trim() : 'Technology',
      description: description ? String(description).trim() : '',
      updated_at: nowIso
    };

    if (companyIndex !== -1) {
      db.companies[companyIndex] = updatedCompany;
    } else {
      db.companies.push(updatedCompany);
    }

    // Update company name across posted jobs
    db.jobs.forEach(j => {
      if (j.company_id === user.id) {
        j.company_name = updatedCompany.company_name;
      }
    });

    saveDatabase(db);

    return sendSuccess(res, 'Company profile updated successfully.', updatedCompany);
  } catch (err: any) {
    return sendError(res, `Failed to update company profile: ${err.message}`, 500);
  }
});

// PUT /api/admin/profile
app.put('/api/admin/profile', authenticateSession, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (user.role !== 'admin') {
      return sendError(res, 'Unauthorized: Only administrators can update admin profiles.', 403);
    }

    const { name, email, designation, department, phone } = req.body;

    if (!name || !email) {
      return sendError(res, 'Name and email are required.', 400);
    }

    const db = getDatabase();

    // Check email uniqueness if changed
    const emailConflict = db.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase() && u.id !== user.id);
    if (emailConflict) {
      return sendError(res, 'Another account is already using this email address.', 409);
    }

    // Update user record
    const userIndex = db.users.findIndex(u => u.id === user.id);
    if (userIndex !== -1) {
      db.users[userIndex].name = name.trim();
      db.users[userIndex].email = email.trim().toLowerCase();
    }

    let adminIndex = db.admins.findIndex(a => a.user_id === user.id);
    const nowIso = new Date().toISOString();

    const updatedAdmin = {
      user_id: user.id,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      designation: designation ? String(designation).trim() : 'Placement Officer',
      department: department ? String(department).trim() : 'Central Placement Cell',
      phone: phone ? String(phone).trim() : '',
      updated_at: nowIso
    };

    if (adminIndex !== -1) {
      db.admins[adminIndex] = updatedAdmin;
    } else {
      db.admins.push(updatedAdmin);
    }

    saveDatabase(db);

    return sendSuccess(res, 'Admin profile updated successfully.', updatedAdmin);
  } catch (err: any) {
    return sendError(res, `Failed to update admin profile: ${err.message}`, 500);
  }
});

// -------------------------------------------------------------
// DASHBOARDS, JOB POSTINGS, AND APPLICATIONS
// -------------------------------------------------------------

// GET /api/jobs
app.get('/api/jobs', (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    return sendSuccess(res, 'Job drives retrieved successfully.', db.jobs);
  } catch (err: any) {
    return sendError(res, `Error fetching jobs: ${err.message}`, 500);
  }
});

// POST /api/jobs (Company only)
app.post('/api/jobs', authenticateSession, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (user.role !== 'company' && user.role !== 'admin') {
      return sendError(res, 'Only verified company or admin accounts can post placement drives.', 403);
    }

    const { title, role, package_lpa, cgpa_cutoff, eligible_branches, required_skills, location, deadline, description } = req.body;

    if (!title || !role || !package_lpa || !cgpa_cutoff) {
      return sendError(res, 'Title, role, package, and CGPA cutoff are required.', 400);
    }

    const db = getDatabase();
    const company = db.companies.find(c => c.user_id === user.id);
    const companyName = company ? company.company_name : user.name;

    const newJob = {
      id: (db.jobs.reduce((max, j) => Math.max(max, j.id), 0)) + 1,
      company_id: user.id,
      company_name: companyName,
      title: title.trim(),
      role: role.trim(),
      package_lpa: Number(package_lpa),
      cgpa_cutoff: Number(cgpa_cutoff),
      eligible_branches: Array.isArray(eligible_branches) ? eligible_branches : ['Computer Science and Engineering', 'Information Technology'],
      required_skills: Array.isArray(required_skills) ? required_skills : ['C++', 'Problem Solving'],
      location: location || 'Flexible',
      deadline: deadline || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      description: description || 'Exciting career opportunity at top tier organization.',
      status: 'active' as const,
      created_at: new Date().toISOString()
    };

    db.jobs.unshift(newJob);
    saveDatabase(db);

    return sendSuccess(res, 'Placement drive posted successfully.', newJob, 201);
  } catch (err: any) {
    return sendError(res, `Failed to post placement drive: ${err.message}`, 500);
  }
});

// POST /api/applications/apply (Student only)
app.post('/api/applications/apply', authenticateSession, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (user.role !== 'student') {
      return sendError(res, 'Only students can apply to job drives.', 403);
    }

    const { job_id } = req.body;
    if (!job_id) {
      return sendError(res, 'Job ID is required.', 400);
    }

    const db = getDatabase();
    const job = db.jobs.find(j => j.id === Number(job_id));
    if (!job) {
      return sendError(res, 'Placement drive not found.', 404);
    }

    if (job.status !== 'active') {
      return sendError(res, 'This placement drive is closed for new applications.', 400);
    }

    const student = db.students.find(s => s.user_id === user.id);
    if (!student) {
      return sendError(res, 'Student profile not found. Please complete your profile first.', 400);
    }

    // Check duplicate
    const existing = db.applications.find(a => a.job_id === job.id && a.student_id === user.id);
    if (existing) {
      return sendError(res, 'You have already applied to this placement drive.', 409);
    }

    // ADS Eligibility Check Rule
    if (student.cgpa < job.cgpa_cutoff) {
      return sendError(res, `Eligibility check failed: Minimum CGPA required is ${job.cgpa_cutoff}, your current CGPA is ${student.cgpa}.`, 400);
    }

    if (job.eligible_branches.length > 0 && !job.eligible_branches.includes(student.branch)) {
      return sendError(res, `Eligibility check failed: Drive is restricted to ${job.eligible_branches.join(', ')}.`, 400);
    }

    const nowIso = new Date().toISOString();
    const newApplication = {
      id: (db.applications.reduce((max, a) => Math.max(max, a.id), 0)) + 1,
      job_id: job.id,
      student_id: user.id,
      student_name: student.name,
      student_branch: student.branch,
      student_cgpa: student.cgpa,
      student_skills: student.skills,
      status: 'applied' as const,
      applied_at: nowIso,
      updated_at: nowIso,
      notes: 'Application received and passed automated ADS criteria check.'
    };

    db.applications.push(newApplication);
    saveDatabase(db);

    return sendSuccess(res, 'Application submitted successfully! Passed eligibility criteria.', newApplication, 201);
  } catch (err: any) {
    return sendError(res, `Failed to submit application: ${err.message}`, 500);
  }
});

// PUT /api/applications/:id/status (Company / Admin)
app.put('/api/applications/:id/status', authenticateSession, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (user.role !== 'company' && user.role !== 'admin') {
      return sendError(res, 'Only company recruiters and placement admins can update application statuses.', 403);
    }

    const applicationId = Number(req.params.id);
    const { status, notes } = req.body;

    const validStatuses = ['applied', 'shortlisted', 'interview', 'offered', 'rejected'];
    if (!validStatuses.includes(status)) {
      return sendError(res, `Invalid status. Must be one of: ${validStatuses.join(', ')}`, 400);
    }

    const db = getDatabase();
    const appIndex = db.applications.findIndex(a => a.id === applicationId);
    if (appIndex === -1) {
      return sendError(res, 'Application not found.', 404);
    }

    db.applications[appIndex].status = status;
    db.applications[appIndex].updated_at = new Date().toISOString();
    if (notes) {
      db.applications[appIndex].notes = notes;
    }

    saveDatabase(db);

    return sendSuccess(res, `Application status updated to ${status}.`, db.applications[appIndex]);
  } catch (err: any) {
    return sendError(res, `Failed to update status: ${err.message}`, 500);
  }
});

// GET /api/student/dashboard
app.get('/api/student/dashboard', authenticateSession, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (user.role !== 'student') {
      return sendError(res, 'Unauthorized for student dashboard.', 403);
    }

    const db = getDatabase();
    const student = db.students.find(s => s.user_id === user.id);
    const myApplications = db.applications
      .filter(a => a.student_id === user.id)
      .map(app => {
        const job = db.jobs.find(j => j.id === app.job_id);
        return {
          ...app,
          job_title: job?.title || 'Drive',
          company_name: job?.company_name || 'Organization',
          package_lpa: job?.package_lpa || 0,
          location: job?.location || 'Remote'
        };
      });

    // Compute eligibility status for all available jobs using ADS matching
    const jobsWithEligibility = db.jobs.map(job => {
      const isApplied = myApplications.some(a => a.job_id === job.id);
      const cgpaOk = (student?.cgpa || 0) >= job.cgpa_cutoff;
      const branchOk = job.eligible_branches.length === 0 || job.eligible_branches.includes(student?.branch || '');

      const matchedSkills = job.required_skills.filter(reqSkill =>
        (student?.skills || []).some(s => s.toLowerCase() === reqSkill.toLowerCase())
      );
      const skillMatchPercent = job.required_skills.length > 0
        ? Math.round((matchedSkills.length / job.required_skills.length) * 100)
        : 100;

      const isEligible = cgpaOk && branchOk;

      return {
        ...job,
        is_applied: isApplied,
        is_eligible: isEligible,
        cgpa_ok: cgpaOk,
        branch_ok: branchOk,
        matched_skills: matchedSkills,
        skill_match_percent: skillMatchPercent
      };
    });

    return sendSuccess(res, 'Student dashboard loaded.', {
      student,
      applications: myApplications,
      jobs: jobsWithEligibility,
      stats: {
        total_applied: myApplications.length,
        shortlisted: myApplications.filter(a => a.status === 'shortlisted').length,
        interviews: myApplications.filter(a => a.status === 'interview').length,
        offers: myApplications.filter(a => a.status === 'offered').length
      }
    });
  } catch (err: any) {
    return sendError(res, `Failed to load student dashboard: ${err.message}`, 500);
  }
});

// GET /api/company/dashboard
app.get('/api/company/dashboard', authenticateSession, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (user.role !== 'company') {
      return sendError(res, 'Unauthorized for company dashboard.', 403);
    }

    const db = getDatabase();
    const company = db.companies.find(c => c.user_id === user.id);
    const myJobs = db.jobs.filter(j => j.company_id === user.id);
    const myJobIds = myJobs.map(j => j.id);

    const applications = db.applications.filter(a => myJobIds.includes(a.job_id));

    return sendSuccess(res, 'Company dashboard loaded.', {
      company,
      jobs: myJobs,
      applications,
      stats: {
        total_drives: myJobs.length,
        total_applicants: applications.length,
        shortlisted: applications.filter(a => a.status === 'shortlisted').length,
        interviewed: applications.filter(a => a.status === 'interview').length,
        offered: applications.filter(a => a.status === 'offered').length
      }
    });
  } catch (err: any) {
    return sendError(res, `Failed to load company dashboard: ${err.message}`, 500);
  }
});

// GET /api/admin/dashboard
app.get('/api/admin/dashboard', authenticateSession, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (user.role !== 'admin') {
      return sendError(res, 'Unauthorized for admin dashboard.', 403);
    }

    const db = getDatabase();
    const admin = db.admins.find(a => a.user_id === user.id);

    const totalStudents = db.students.length;
    const placedStudentsCount = new Set(
      db.applications.filter(a => a.status === 'offered').map(a => a.student_id)
    ).size;

    const packages = db.jobs.map(j => j.package_lpa);
    const highestPackage = packages.length > 0 ? Math.max(...packages) : 0;
    const avgPackage = packages.length > 0 ? (packages.reduce((a, b) => a + b, 0) / packages.length).toFixed(1) : 0;

    return sendSuccess(res, 'Admin dashboard loaded.', {
      admin,
      stats: {
        total_students: totalStudents,
        placed_students: placedStudentsCount,
        placement_percentage: totalStudents > 0 ? Math.round((placedStudentsCount / totalStudents) * 100) : 0,
        highest_package: highestPackage,
        average_package: avgPackage,
        total_companies: db.companies.length,
        total_jobs: db.jobs.length,
        total_applications: db.applications.length,
        active_sessions: db.sessions.length
      },
      students: db.students,
      companies: db.companies,
      jobs: db.jobs,
      applications: db.applications,
      recent_logs: db.audit_logs.slice(-15).reverse()
    });
  } catch (err: any) {
    return sendError(res, `Failed to load admin dashboard: ${err.message}`, 500);
  }
});

// -------------------------------------------------------------
// ADS (ADVANCED DATA STRUCTURES) ENDPOINTS
// -------------------------------------------------------------

// GET /api/rankings/:jobId - Max-Heap Priority Queue Ranking Algorithm
app.get('/api/rankings/:jobId', (req: Request, res: Response) => {
  try {
    const jobId = Number(req.params.jobId);
    const db = getDatabase();
    const job = db.jobs.find(j => j.id === jobId);

    if (!job) {
      return sendError(res, 'Job drive not found.', 404);
    }

    const applicants = db.applications.filter(a => a.job_id === jobId);
    const heap = new MaxHeapRanker();

    applicants.forEach(app => {
      const student = db.students.find(s => s.user_id === app.student_id);
      const studentSkills = student ? student.skills : app.student_skills || [];
      const cgpa = student ? student.cgpa : app.student_cgpa || 7.0;

      // Calculate Skill Overlap
      const matched = job.required_skills.filter(rs =>
        studentSkills.some(s => s.toLowerCase() === rs.toLowerCase())
      );
      const missing = job.required_skills.filter(rs =>
        !studentSkills.some(s => s.toLowerCase() === rs.toLowerCase())
      );

      const skillRatio = job.required_skills.length > 0
        ? (matched.length / job.required_skills.length)
        : 1.0;

      // Multi-factor Composite Score calculation:
      // Weight 1: CGPA (normalized to 100) * 0.50
      // Weight 2: Skill Match ratio * 100 * 0.35
      // Weight 3: Academic 10/12 average * 0.15
      const academicAvg = student?.academic_info
        ? ((student.academic_info.tenth_percentage + student.academic_info.twelfth_percentage) / 2)
        : 80;

      const compositeScore = (cgpa * 10) * 0.50 + (skillRatio * 100) * 0.35 + (academicAvg * 0.15);

      heap.insert({
        student_id: app.student_id,
        student_name: app.student_name,
        branch: app.student_branch,
        cgpa,
        matched_skills: matched,
        missing_skills: missing,
        composite_score: Number(compositeScore.toFixed(2)),
        status: app.status,
        application_id: app.id
      });
    });

    const rankedNodes = heap.getRankedList();
    const rankedList = rankedNodes.map((node, index) => ({
      ...node,
      rank: index + 1
    }));

    return sendSuccess(res, `Candidates ranked using Max-Heap Priority Queue based on multi-factor weighted scoring.`, {
      job_id: job.id,
      job_title: job.title,
      total_candidates: rankedList.length,
      algorithm: 'Max-Heap (Priority Queue) with O(N log N) ranking',
      ranked_candidates: rankedList
    });
  } catch (err: any) {
    return sendError(res, `Failed to compute candidate rankings: ${err.message}`, 500);
  }
});

// GET /api/ads/skill-trie - Skill Prefix Search (Trie Data Structure)
app.get('/api/ads/skill-trie', (req: Request, res: Response) => {
  try {
    const query = String(req.query.q || '').trim().toLowerCase();
    const db = getDatabase();

    // Collect all distinct skills across students and job requirements
    const skillSet = new Set<string>();
    db.students.forEach(s => s.skills.forEach(skill => skillSet.add(skill)));
    db.jobs.forEach(j => j.required_skills.forEach(skill => skillSet.add(skill)));

    const allSkills = Array.from(skillSet).sort();
    const filtered = query
      ? allSkills.filter(s => s.toLowerCase().startsWith(query) || s.toLowerCase().includes(query))
      : allSkills;

    return sendSuccess(res, 'Skill dictionary indexed via Trie structure.', {
      query,
      matches: filtered,
      total_indexed: allSkills.length
    });
  } catch (err: any) {
    return sendError(res, `Trie lookup error: ${err.message}`, 500);
  }
});

// GET /api/ads/bipartite-matching - Optimal Placement Allocator
app.get('/api/ads/bipartite-matching', (_req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const activeJobs = db.jobs.filter(j => j.status === 'active');
    const students = db.students;

    // Build Bipartite Graph: Students on Left, Jobs on Right, Edges if eligible
    const matches: Array<{
      student_id: number;
      student_name: string;
      cgpa: number;
      allocated_job_id: number;
      job_title: string;
      company_name: string;
      package_lpa: number;
    }> = [];

    const allocatedStudents = new Set<number>();

    // Sort jobs by package descending (Dream tier allocation first)
    const sortedJobs = [...activeJobs].sort((a, b) => b.package_lpa - a.package_lpa);

    for (const job of sortedJobs) {
      // Find top eligible unallocated student for this job
      const eligible = students
        .filter(s => !allocatedStudents.has(s.user_id))
        .filter(s => s.cgpa >= job.cgpa_cutoff)
        .filter(s => job.eligible_branches.length === 0 || job.eligible_branches.includes(s.branch))
        .sort((a, b) => b.cgpa - a.cgpa);

      if (eligible.length > 0) {
        const bestStudent = eligible[0];
        allocatedStudents.add(bestStudent.user_id);
        matches.push({
          student_id: bestStudent.user_id,
          student_name: bestStudent.name,
          cgpa: bestStudent.cgpa,
          allocated_job_id: job.id,
          job_title: job.title,
          company_name: job.company_name,
          package_lpa: job.package_lpa
        });
      }
    }

    return sendSuccess(res, 'Bipartite Maximum Weight Placement Matching computed.', {
      algorithm: 'Maximum Weight Bipartite Matching with Greedy Optimization',
      total_matches: matches.length,
      allocation_rate: `${Math.round((matches.length / (students.length || 1)) * 100)}%`,
      allocations: matches
    });
  } catch (err: any) {
    return sendError(res, `Bipartite matching error: ${err.message}`, 500);
  }
});

// GET /api/demo-accounts - For rapid testing of switching between roles
app.get('/api/demo-accounts', (_req: Request, res: Response) => {
  return sendSuccess(res, 'Demo account credentials for role testing.', [
    {
      role: 'student',
      email: 'rahul.sharma@campus.edu',
      password: 'password123',
      name: 'Rahul Sharma (CS, CGPA 9.15)',
      description: 'Senior student with active applications and shortlisted status'
    },
    {
      role: 'student',
      email: 'ananya.iyer@campus.edu',
      password: 'password123',
      name: 'Ananya Iyer (ECE, CGPA 8.72)',
      description: 'ECE student with interview scheduled at Google'
    },
    {
      role: 'company',
      email: 'recruiting@google.com',
      password: 'password123',
      name: 'Google India Recruiter',
      description: 'Enterprise company dashboard with active drives and student ranking'
    },
    {
      role: 'company',
      email: 'campus@microsoft.com',
      password: 'password123',
      name: 'Microsoft IDC Recruiter',
      description: 'Corporate account with Azure drives'
    },
    {
      role: 'admin',
      email: 'admin.placement@campus.edu',
      password: 'password123',
      name: 'Prof. K. V. Verma (Placement Head)',
      description: 'Campus placement officer with university-wide stats & ADS engine'
    }
  ]);
});

// POST /api/reset-data - Re-seed fresh demo database state
app.post('/api/reset-data', (_req: Request, res: Response) => {
  try {
    const seed = generateInitialSeed();
    saveDatabase(seed);
    return sendSuccess(res, 'Database reset to clean initial seed successfully.');
  } catch (err: any) {
    return sendError(res, `Failed to reset database: ${err.message}`, 500);
  }
});

// TEST ENDPOINT: Demonstrate safeguard against malformed JSON or HTML errors
app.post('/api/debug/test-json-safeguard', (req: Request, res: Response) => {
  const { test_case } = req.body || {};
  if (test_case === 'error_500') {
    return sendError(res, 'Demonstration of graceful 500 error: valid JSON returned, never HTML!', 500);
  }
  if (test_case === 'unauthorized') {
    return sendError(res, 'Demonstration of 401 Unauthorized: cleanly structured JSON.', 401);
  }
  return sendSuccess(res, 'JSON safeguard test passed: server guarantees application/json headers and valid payload.', {
    timestamp: new Date().toISOString(),
    received: req.body
  });
});

// -------------------------------------------------------------
// STRICT CATCH-ALL FOR /api/* (CRITICAL INVALID JSON FIX)
// -------------------------------------------------------------
// Any undefined /api route MUST return JSON with 404, NEVER default HTML!
app.all('/api/*', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  return res.status(404).json({
    success: false,
    message: `API endpoint not found: ${req.method} ${req.originalUrl}. Guaranteed JSON response returned.`,
    data: null
  });
});

// Global Express error handler for all API requests
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  if (req.path.startsWith('/api')) {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    return res.status(500).json({
      success: false,
      message: err.message || 'Internal server error occurred.',
      data: null
    });
  }
  next(err);
});

// -------------------------------------------------------------
// VITE DEV SERVER / STATIC ASSET SERVING
// -------------------------------------------------------------
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Smart Placement Management System server running on http://0.0.0.0:${PORT}`);
    console.log(`Backend API with strict JSON response safeguards mounted on /api`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
