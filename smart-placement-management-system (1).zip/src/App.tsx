/**
 * Smart Placement Management System
 * Full-Stack Placement Automation with Resilient Multi-Role Session Switching
 */

import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { AuthScreen } from './components/AuthScreen';
import { StudentDashboard } from './components/StudentDashboard';
import { CompanyDashboard } from './components/CompanyDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { JsonDebugMonitor } from './components/JsonDebugMonitor';

const MainContent: React.FC = () => {
  const { user, role, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-200 animate-bounce mb-4">
          <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
        </div>
        <p className="text-sm font-semibold text-slate-700">Verifying Placement System Session...</p>
        <p className="text-xs text-slate-400 mt-1">Connecting to C++ Crow / Express SQLite Core</p>
      </div>
    );
  }

  // If unauthenticated or actively switching accounts, show the welcome/auth screen
  if (!user || !role) {
    return <AuthScreen />;
  }

  // Render role-specific dashboard with total state isolation
  return (
    <main className="min-h-[calc(100vh-4rem)]">
      {role === 'student' && <StudentDashboard key={`student-${user.id}`} />}
      {role === 'company' && <CompanyDashboard key={`company-${user.id}`} />}
      {role === 'admin' && <AdminDashboard key={`admin-${user.id}`} />}
    </main>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
        <Navbar />
        <div className="flex-1">
          <MainContent />
        </div>
        <JsonDebugMonitor />
      </div>
    </AuthProvider>
  );
}
