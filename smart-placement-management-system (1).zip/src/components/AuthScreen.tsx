import React, { useState } from 'react';
import {
  GraduationCap,
  Building2,
  ShieldCheck,
  LogIn,
  UserPlus,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Lock,
  Mail,
  User,
  Phone,
  Briefcase
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';

export const AuthScreen: React.FC = () => {
  const { login, register, error, clearError, switchingAccount } = useAuth();

  const [activeTab, setActiveTab] = useState<'signin' | 'register' | 'switch'>(
    switchingAccount ? 'switch' : 'signin'
  );

  // Form states
  const [role, setRole] = useState<UserRole>('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [branch, setBranch] = useState('Computer Science and Engineering');
  const [cgpa, setCgpa] = useState('8.5');
  const [companyName, setCompanyName] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError: boolean } | null>(null);

  // Quick Switcher / Demo Accounts
  const demoAccounts = [
    {
      role: 'student' as UserRole,
      title: 'Rahul Sharma (Student)',
      subtitle: 'CSE Senior • CGPA 9.15 • Shortlisted at Google India',
      email: 'rahul.sharma@campus.edu',
      password: 'password123',
      icon: GraduationCap,
      color: 'border-emerald-200 bg-emerald-50/70 text-emerald-900 hover:border-emerald-400'
    },
    {
      role: 'student' as UserRole,
      title: 'Ananya Iyer (Student)',
      subtitle: 'ECE Senior • CGPA 8.72 • Interview Scheduled at Google',
      email: 'ananya.iyer@campus.edu',
      password: 'password123',
      icon: GraduationCap,
      color: 'border-teal-200 bg-teal-50/70 text-teal-900 hover:border-teal-400'
    },
    {
      role: 'company' as UserRole,
      title: 'Google India (Recruiter)',
      subtitle: 'Tech Recruiter • 2 Active Drives (Software & Hardware)',
      email: 'recruiting@google.com',
      password: 'password123',
      icon: Building2,
      color: 'border-blue-200 bg-blue-50/70 text-blue-900 hover:border-blue-400'
    },
    {
      role: 'company' as UserRole,
      title: 'Microsoft IDC (Recruiter)',
      subtitle: 'Azure Campus Drive • 28 LPA • Live Applicant Heap',
      email: 'campus@microsoft.com',
      password: 'password123',
      icon: Building2,
      color: 'border-cyan-200 bg-cyan-50/70 text-cyan-900 hover:border-cyan-400'
    },
    {
      role: 'admin' as UserRole,
      title: 'Prof. K. V. Verma (Placement Head)',
      subtitle: 'Placement Officer • Bipartite ADS Matcher & System Logs',
      email: 'admin.placement@campus.edu',
      password: 'password123',
      icon: ShieldCheck,
      color: 'border-purple-200 bg-purple-50/70 text-purple-900 hover:border-purple-400'
    }
  ];

  const handleQuickLogin = async (accEmail: string, accPass: string, accRole: UserRole) => {
    clearError();
    setSubmitting(true);
    setStatusMessage({ text: `Switching to ${accEmail} (${accRole})...`, isError: false });

    const result = await login(accEmail, accPass, accRole);
    setSubmitting(false);

    if (!result.success) {
      setStatusMessage({ text: result.message, isError: true });
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setSubmitting(true);
    setStatusMessage(null);

    const result = await login(email, password, role);
    setSubmitting(false);

    if (!result.success) {
      setStatusMessage({ text: result.message, isError: true });
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setSubmitting(true);
    setStatusMessage(null);

    const payload: any = {
      email,
      password,
      role,
      name: role === 'company' ? companyName : name,
      phone
    };

    if (role === 'student') {
      payload.branch = branch;
      payload.cgpa = parseFloat(cgpa) || 7.5;
    } else if (role === 'company') {
      payload.company_name = companyName;
    }

    const result = await register(payload);
    setSubmitting(false);

    if (!result.success) {
      setStatusMessage({ text: result.message, isError: true });
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col justify-center py-8 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-slate-50 via-indigo-50/30 to-slate-100">
      <div className="sm:mx-auto sm:w-full sm:max-w-2xl">
        {/* Top welcome headline */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 text-indigo-700 text-xs font-semibold mb-3 border border-indigo-200 shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" /> Smart Campus Recruitment Portal
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight sm:text-4xl">
            Smart Placement Management System
          </h2>
          <p className="mt-2 text-sm text-slate-600 max-w-lg mx-auto">
            Unified authentication for Students, Corporate Recruiters, and Placement Administrators with C++17 ADS backend and resilient JSON session switching.
          </p>
        </div>

        {/* Tab navigation card */}
        <div className="bg-white rounded-3xl shadow-xl border border-slate-200/80 overflow-hidden">
          {/* Main 3 Options: Sign In, Create New Account, Switch Account */}
          <div className="grid grid-cols-3 border-b border-slate-200 bg-slate-50/80 p-1.5 gap-1.5 text-xs font-semibold">
            <button
              onClick={() => {
                setActiveTab('signin');
                clearError();
                setStatusMessage(null);
              }}
              className={`py-3 px-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
                activeTab === 'signin'
                  ? 'bg-white text-indigo-700 shadow-xs font-bold border border-slate-200/60'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <LogIn className="w-4 h-4 text-indigo-600" />
              <span>Sign In</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('register');
                clearError();
                setStatusMessage(null);
              }}
              className={`py-3 px-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
                activeTab === 'register'
                  ? 'bg-white text-indigo-700 shadow-xs font-bold border border-slate-200/60'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <UserPlus className="w-4 h-4 text-indigo-600" />
              <span>Create Account</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('switch');
                clearError();
                setStatusMessage(null);
              }}
              className={`py-3 px-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
                activeTab === 'switch'
                  ? 'bg-white text-indigo-700 shadow-xs font-bold border border-slate-200/60'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <RefreshCw className="w-4 h-4 text-indigo-600" />
              <span>Switch Account</span>
            </button>
          </div>

          <div className="p-6 sm:p-8">
            {/* Display status or error alert */}
            {(statusMessage || error) && (
              <div
                className={`mb-6 p-4 rounded-xl text-sm flex items-start gap-3 animate-in fade-in ${
                  statusMessage && !statusMessage.isError
                    ? 'bg-indigo-50 border border-indigo-200 text-indigo-800'
                    : 'bg-red-50 border border-red-200 text-red-800'
                }`}
              >
                {statusMessage && !statusMessage.isError ? (
                  <CheckCircle2 className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                )}
                <div className="flex-1">
                  <p className="font-medium">{statusMessage?.text || error}</p>
                </div>
              </div>
            )}

            {/* TAB 1: SIGN IN */}
            {activeTab === 'signin' && (
              <div>
                <div className="mb-6">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                    Select Your Role *
                  </label>
                  <div className="grid grid-cols-3 gap-2.5">
                    <button
                      type="button"
                      onClick={() => setRole('student')}
                      className={`p-3 rounded-xl border text-center transition flex flex-col items-center gap-1.5 ${
                        role === 'student'
                          ? 'border-emerald-500 bg-emerald-50/70 text-emerald-800 font-bold ring-2 ring-emerald-400/30'
                          : 'border-slate-200 hover:border-slate-300 text-slate-600 bg-slate-50/50'
                      }`}
                    >
                      <GraduationCap className="w-5 h-5 text-emerald-600" />
                      <span className="text-xs">Student</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRole('company')}
                      className={`p-3 rounded-xl border text-center transition flex flex-col items-center gap-1.5 ${
                        role === 'company'
                          ? 'border-blue-500 bg-blue-50/70 text-blue-800 font-bold ring-2 ring-blue-400/30'
                          : 'border-slate-200 hover:border-slate-300 text-slate-600 bg-slate-50/50'
                      }`}
                    >
                      <Building2 className="w-5 h-5 text-blue-600" />
                      <span className="text-xs">Company</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRole('admin')}
                      className={`p-3 rounded-xl border text-center transition flex flex-col items-center gap-1.5 ${
                        role === 'admin'
                          ? 'border-purple-500 bg-purple-50/70 text-purple-800 font-bold ring-2 ring-purple-400/30'
                          : 'border-slate-200 hover:border-slate-300 text-slate-600 bg-slate-50/50'
                      }`}
                    >
                      <ShieldCheck className="w-5 h-5 text-purple-600" />
                      <span className="text-xs">Admin</span>
                    </button>
                  </div>
                </div>

                <form onSubmit={handleSignIn} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Email Address *
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        placeholder="e.g. rahul.sharma@campus.edu"
                        className="w-full pl-10 pr-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Password *
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="password"
                        required
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full pl-10 pr-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-md shadow-indigo-200 transition flex items-center justify-center gap-2 text-sm disabled:opacity-50"
                  >
                    {submitting ? (
                      <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <LogIn className="w-4 h-4" />
                        <span>Sign In as {role.charAt(0).toUpperCase() + role.slice(1)}</span>
                      </>
                    )}
                  </button>
                </form>

                {/* Quick 1-click test fill for convenience */}
                <div className="mt-6 pt-5 border-t border-slate-100">
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2.5 text-center">
                    Instant Demo Login (1-Click Fill)
                  </p>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => {
                        setEmail('rahul.sharma@campus.edu');
                        setPassword('password123');
                        setRole('student');
                      }}
                      className="px-2.5 py-2 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 font-medium transition truncate text-center"
                    >
                      Fill Student
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEmail('recruiting@google.com');
                        setPassword('password123');
                        setRole('company');
                      }}
                      className="px-2.5 py-2 rounded-lg bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 font-medium transition truncate text-center"
                    >
                      Fill Company
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEmail('admin.placement@campus.edu');
                        setPassword('password123');
                        setRole('admin');
                      }}
                      className="px-2.5 py-2 rounded-lg bg-purple-50 text-purple-700 border border-purple-200 hover:bg-purple-100 font-medium transition truncate text-center"
                    >
                      Fill Admin
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: CREATE NEW ACCOUNT */}
            {activeTab === 'register' && (
              <div>
                <div className="mb-5">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                    Select Account Type *
                  </label>
                  <div className="grid grid-cols-3 gap-2.5">
                    <button
                      type="button"
                      onClick={() => setRole('student')}
                      className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center gap-1 ${
                        role === 'student'
                          ? 'border-emerald-500 bg-emerald-50/70 text-emerald-800 font-bold ring-2 ring-emerald-400/30'
                          : 'border-slate-200 hover:border-slate-300 text-slate-600 bg-slate-50/50'
                      }`}
                    >
                      <GraduationCap className="w-4 h-4 text-emerald-600" />
                      <span className="text-xs">Student</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRole('company')}
                      className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center gap-1 ${
                        role === 'company'
                          ? 'border-blue-500 bg-blue-50/70 text-blue-800 font-bold ring-2 ring-blue-400/30'
                          : 'border-slate-200 hover:border-slate-300 text-slate-600 bg-slate-50/50'
                      }`}
                    >
                      <Building2 className="w-4 h-4 text-blue-600" />
                      <span className="text-xs">Company</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRole('admin')}
                      className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center gap-1 ${
                        role === 'admin'
                          ? 'border-purple-500 bg-purple-50/70 text-purple-800 font-bold ring-2 ring-purple-400/30'
                          : 'border-slate-200 hover:border-slate-300 text-slate-600 bg-slate-50/50'
                      }`}
                    >
                      <ShieldCheck className="w-4 h-4 text-purple-600" />
                      <span className="text-xs">Admin</span>
                    </button>
                  </div>
                </div>

                <form onSubmit={handleRegister} className="space-y-3.5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        {role === 'company' ? 'Company Name *' : 'Full Name *'}
                      </label>
                      <div className="relative">
                        {role === 'company' ? (
                          <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                        ) : (
                          <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                        )}
                        <input
                          type="text"
                          required
                          value={role === 'company' ? companyName : name}
                          onChange={e => {
                            if (role === 'company') setCompanyName(e.target.value);
                            else setName(e.target.value);
                          }}
                          placeholder={role === 'company' ? 'Acme Corp' : 'John Doe'}
                          className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Email Address *
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                        <input
                          type="email"
                          required
                          value={email}
                          onChange={e => setEmail(e.target.value)}
                          placeholder="email@example.com"
                          className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Password (min 6 chars) *
                      </label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                        <input
                          type="password"
                          required
                          minLength={6}
                          value={password}
                          onChange={e => setPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Phone Number
                      </label>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                        <input
                          type="tel"
                          value={phone}
                          onChange={e => setPhone(e.target.value)}
                          placeholder="+91 98765 00000"
                          className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                        />
                      </div>
                    </div>
                  </div>

                  {role === 'student' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Branch *
                        </label>
                        <select
                          value={branch}
                          onChange={e => setBranch(e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                        >
                          <option value="Computer Science and Engineering">Computer Science & Engg</option>
                          <option value="Information Technology">Information Technology</option>
                          <option value="Electronics and Communication">Electronics & Communication</option>
                          <option value="Electrical Engineering">Electrical Engineering</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Current CGPA *
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          min={0}
                          max={10}
                          value={cgpa}
                          onChange={e => setCgpa(e.target.value)}
                          placeholder="8.5"
                          className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                        />
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full mt-2 py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-md shadow-indigo-200 transition flex items-center justify-center gap-2 text-sm disabled:opacity-50"
                  >
                    {submitting ? (
                      <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>Register as {role.charAt(0).toUpperCase() + role.slice(1)}</span>
                      </>
                    )}
                  </button>
                </form>
              </div>
            )}

            {/* TAB 3: SWITCH ACCOUNT (DEDICATED SWITCHER) */}
            {activeTab === 'switch' && (
              <div>
                <div className="mb-4">
                  <div className="flex items-center gap-2 text-indigo-700 font-bold text-sm mb-1">
                    <RefreshCw className="w-4 h-4" />
                    <span>Dedicated Account Switching Station</span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Seamlessly test switching between Students, Companies, and Admins. All previous user state is safely wiped from memory and requests are cleanly cancelled without any "Invalid JSON" error.
                  </p>
                </div>

                <div className="space-y-2.5">
                  {demoAccounts.map((acc, index) => {
                    const IconComponent = acc.icon;
                    return (
                      <div
                        key={index}
                        className={`p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 ${acc.color}`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-white shadow-2xs flex items-center justify-center shrink-0">
                            <IconComponent className="w-5 h-5 text-slate-800" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-bold text-slate-900">{acc.title}</h4>
                              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-md bg-white/80 border border-slate-200 text-slate-700">
                                {acc.role}
                              </span>
                            </div>
                            <p className="text-xs text-slate-600 mt-0.5">{acc.subtitle}</p>
                            <span className="text-[11px] font-mono text-slate-500">{acc.email}</span>
                          </div>
                        </div>

                        <button
                          type="button"
                          disabled={submitting}
                          onClick={() => handleQuickLogin(acc.email, acc.password, acc.role)}
                          className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-900 hover:text-white text-slate-800 font-semibold text-xs border border-slate-300 shadow-2xs transition flex items-center gap-1.5 shrink-0"
                        >
                          <span>Switch Now</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  })}
                </div>

                <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600">
                  <span className="font-semibold text-slate-800">Verification note:</span> Clicking "Switch Now" sends an explicit logout, cancels any ongoing fetch streams, resets the React store, and mounts the target role's dashboard with guaranteed JSON payloads.
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
