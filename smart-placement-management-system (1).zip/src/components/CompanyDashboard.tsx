import React, { useState, useEffect, useCallback } from 'react';
import {
  Building2,
  Briefcase,
  Users,
  Plus,
  CheckCircle2,
  Clock,
  Award,
  AlertCircle,
  Sparkles,
  Layers,
  ChevronRight,
  TrendingUp,
  MapPin,
  Globe,
  RefreshCw,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { CompanyProfile, JobDrive, Application, RankedCandidate } from '../types';
import { EditProfileModal } from './EditProfileModal';

export const CompanyDashboard: React.FC = () => {
  const { user } = useAuth();
  const [company, setCompany] = useState<CompanyProfile | null>(null);
  const [jobs, setJobs] = useState<JobDrive[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [stats, setStats] = useState({ total_drives: 0, total_applicants: 0, shortlisted: 0, interviewed: 0, offered: 0 });

  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);
  const [rankedCandidates, setRankedCandidates] = useState<RankedCandidate[]>([]);
  const [rankingAlgoInfo, setRankingAlgoInfo] = useState<string>('');

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const [showPostJobModal, setShowPostJobModal] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);

  // New Job Form
  const [jobForm, setJobForm] = useState({
    title: '',
    role: '',
    package_lpa: 24,
    cgpa_cutoff: 8.0,
    eligible_branches: ['Computer Science and Engineering', 'Information Technology'],
    required_skills: 'C++, Python, Algorithms, Data Structures',
    location: 'Bengaluru / Hyderabad',
    deadline: '2026-12-30',
    description: ''
  });

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.company.getDashboard();
      if (res.success && res.data) {
        setCompany(res.data.company);
        setJobs(res.data.jobs);
        setApplications(res.data.applications);
        setStats(res.data.stats);

        if (res.data.jobs.length > 0 && selectedJobId === null) {
          setSelectedJobId(res.data.jobs[0].id);
        }
      } else {
        setError(res.message || 'Failed to load company dashboard');
      }
    } catch (err: any) {
      setError(err.message || 'Network error loading company dashboard');
    } finally {
      setLoading(false);
    }
  }, [selectedJobId]);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  // Load Max-Heap ranking when selected drive changes
  const loadRankings = useCallback(async (jobId: number) => {
    try {
      const res = await api.company.getRankings(jobId);
      if (res.success && res.data) {
        setRankedCandidates(res.data.ranked_candidates);
        setRankingAlgoInfo(res.data.algorithm);
      }
    } catch (err: any) {
      console.error('Error fetching candidate rankings:', err);
    }
  }, []);

  useEffect(() => {
    if (selectedJobId) {
      loadRankings(selectedJobId);
    }
  }, [selectedJobId, loadRankings]);

  const handlePostJob = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const skillsArray = jobForm.required_skills
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    try {
      const res = await api.company.postJob({
        title: jobForm.title,
        role: jobForm.role,
        package_lpa: Number(jobForm.package_lpa),
        cgpa_cutoff: Number(jobForm.cgpa_cutoff),
        eligible_branches: jobForm.eligible_branches,
        required_skills: skillsArray,
        location: jobForm.location,
        deadline: jobForm.deadline,
        description: jobForm.description
      });

      if (res.success && res.data) {
        setSuccessToast(`Placement drive "${res.data.title}" posted successfully!`);
        setShowPostJobModal(false);
        setJobForm({
          title: '',
          role: '',
          package_lpa: 24,
          cgpa_cutoff: 8.0,
          eligible_branches: ['Computer Science and Engineering', 'Information Technology'],
          required_skills: 'C++, Python, Algorithms, Data Structures',
          location: 'Bengaluru / Hyderabad',
          deadline: '2026-12-30',
          description: ''
        });
        await loadDashboard();
        setSelectedJobId(res.data.id);
      } else {
        setError(res.message || 'Failed to post drive');
      }
    } catch (err: any) {
      setError(err.message || 'Error posting drive');
    }
  };

  const handleStatusChange = async (applicationId: number, status: string) => {
    try {
      const res = await api.company.updateApplicationStatus(applicationId, status);
      if (res.success) {
        setSuccessToast(`Application status updated to "${status}".`);
        if (selectedJobId) {
          await loadRankings(selectedJobId);
        }
        await loadDashboard();
      } else {
        setError(res.message || 'Failed to update candidate status');
      }
    } catch (err: any) {
      setError(err.message || 'Error updating status');
    }
  };

  const selectedJob = jobs.find(j => j.id === selectedJobId);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 sm:p-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-2xl shadow-md shadow-blue-200 shrink-0">
              <Building2 className="w-9 h-9" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  {company?.company_name || user?.name}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                  {company?.industry || 'Enterprise Technology'}
                </span>
              </div>
              <p className="text-sm text-slate-600 mt-1 flex items-center gap-3 flex-wrap">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  {company?.location || 'Bengaluru / Hyderabad'}
                </span>
                <span className="flex items-center gap-1">
                  <Globe className="w-3.5 h-3.5 text-slate-400" />
                  {company?.website || 'https://careers.google.com'}
                </span>
              </p>
              <p className="text-xs text-slate-500 mt-2 max-w-2xl line-clamp-2">
                {company?.description || 'Corporate recruitment partner conducting campus placement drives.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 self-start md:self-center shrink-0">
            <button
              onClick={() => setShowPostJobModal(true)}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Post New Placement Drive
            </button>
            <button
              onClick={() => setShowEditProfile(true)}
              className="px-4 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition"
            >
              Edit Recruiter Profile
            </button>
            <button
              onClick={loadDashboard}
              title="Refresh dashboard"
              className="p-2.5 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl transition"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5 mt-8 pt-6 border-t border-slate-100">
          <div className="p-3.5 rounded-2xl bg-slate-50/70 border border-slate-200/70">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Drives</p>
            <p className="text-2xl font-bold text-slate-900 mt-1">{stats.total_drives}</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-indigo-50/70 border border-indigo-200/70">
            <p className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">Total Applicants</p>
            <p className="text-2xl font-bold text-indigo-900 mt-1">{stats.total_applicants}</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-200/70">
            <p className="text-xs font-semibold text-blue-600 uppercase tracking-wider">Shortlisted</p>
            <p className="text-2xl font-bold text-blue-900 mt-1">{stats.shortlisted}</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200/70">
            <p className="text-xs font-semibold text-amber-600 uppercase tracking-wider">Interviews</p>
            <p className="text-2xl font-bold text-amber-900 mt-1">{stats.interviewed}</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200/70">
            <p className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">Offers Given</p>
            <p className="text-2xl font-bold text-emerald-900 mt-1">{stats.offered}</p>
          </div>
        </div>
      </div>

      {/* Toast Feedback */}
      {successToast && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-sm flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{successToast}</span>
          </div>
          <button onClick={() => setSuccessToast(null)} className="text-emerald-700 hover:text-emerald-900">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-800 rounded-2xl text-sm flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={() => setError(null)} className="text-red-700 hover:text-red-900">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Drive Selector Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Briefcase className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">Active Placement Drive Candidate Pool</h3>
            <p className="text-xs text-slate-500">Select a drive to inspect applicants and execute ADS Max-Heap ranking</p>
          </div>
        </div>

        <div className="w-full sm:w-auto min-w-[280px]">
          <select
            value={selectedJobId || ''}
            onChange={e => setSelectedJobId(Number(e.target.value))}
            className="w-full px-3.5 py-2 text-sm font-semibold border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
          >
            {jobs.map(job => (
              <option key={job.id} value={job.id}>
                {job.title} ({job.package_lpa} LPA)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Selected Drive Details & ADS Ranking Engine */}
      {selectedJob && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Drive Specifications Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold">
                {selectedJob.package_lpa} LPA Package
              </span>
              <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                Active Drive
              </span>
            </div>

            <div>
              <h2 className="text-lg font-bold text-slate-900">{selectedJob.title}</h2>
              <p className="text-xs text-slate-500 mt-0.5">{selectedJob.role}</p>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Minimum CGPA Cutoff:</span>
                <span className="font-bold text-slate-800">{selectedJob.cgpa_cutoff}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Application Deadline:</span>
                <span className="font-bold text-slate-800">{selectedJob.deadline}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Location:</span>
                <span className="font-bold text-slate-800">{selectedJob.location}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100">
              <p className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Required Skills</p>
              <div className="flex flex-wrap gap-1.5">
                {selectedJob.required_skills.map((s, idx) => (
                  <span key={idx} className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-xs font-medium border border-slate-200">
                    {s}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-3.5 bg-gradient-to-br from-indigo-50 to-violet-50 rounded-2xl border border-indigo-100 text-xs text-indigo-900">
              <div className="flex items-center gap-1.5 font-bold mb-1 text-indigo-700">
                <Sparkles className="w-3.5 h-3.5" />
                <span>ADS Ranking Formula</span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Ranked with Max-Heap: Composite Score = (CGPA × 10) × 0.50 + (Skill Match % × 0.35) + (Academic 10th/12th Avg × 0.15). Root of heap always holds the highest scoring candidate in O(log N).
              </p>
            </div>
          </div>

          {/* Ranked Candidates Table / Max-Heap View */}
          <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">
                  ADS Max-Heap Ranked Leaderboard ({rankedCandidates.length} Applicants)
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-1 rounded-md border border-slate-200">
                Heap Extraction: O(N log N)
              </span>
            </div>

            <div className="space-y-3">
              {rankedCandidates.map(cand => (
                <div
                  key={cand.student_id}
                  className={`p-4 rounded-2xl border transition ${
                    cand.rank === 1
                      ? 'border-amber-300 bg-amber-50/30 ring-2 ring-amber-400/20'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      {/* Rank Medal */}
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 ${
                        cand.rank === 1
                          ? 'bg-amber-400 text-amber-950 shadow-md shadow-amber-200'
                          : cand.rank === 2
                          ? 'bg-slate-300 text-slate-800'
                          : cand.rank === 3
                          ? 'bg-amber-700/30 text-amber-900'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}>
                        #{cand.rank}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-slate-900">{cand.student_name}</h4>
                          <span className="text-xs text-slate-500">• {cand.branch}</span>
                        </div>
                        <div className="flex items-center gap-3 mt-1 text-xs">
                          <span className="font-bold text-indigo-700">CGPA: {cand.cgpa.toFixed(2)}</span>
                          <span className="text-slate-400">•</span>
                          <span className="font-bold text-emerald-700">
                            Score: {cand.composite_score.toFixed(1)} / 100
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Status Changer Actions */}
                    <div className="flex items-center gap-1.5 flex-wrap self-end sm:self-center">
                      <button
                        onClick={() => handleStatusChange(cand.application_id, 'shortlisted')}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition ${
                          cand.status === 'shortlisted'
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100'
                        }`}
                      >
                        Shortlist
                      </button>

                      <button
                        onClick={() => handleStatusChange(cand.application_id, 'interview')}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition ${
                          cand.status === 'interview'
                            ? 'bg-amber-600 text-white border-amber-600'
                            : 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
                        }`}
                      >
                        Interview
                      </button>

                      <button
                        onClick={() => handleStatusChange(cand.application_id, 'offered')}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition ${
                          cand.status === 'offered'
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                        }`}
                      >
                        Offer
                      </button>

                      <button
                        onClick={() => handleStatusChange(cand.application_id, 'rejected')}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition ${
                          cand.status === 'rejected'
                            ? 'bg-red-600 text-white border-red-600'
                            : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-red-50 hover:text-red-700'
                        }`}
                      >
                        Reject
                      </button>
                    </div>
                  </div>

                  {/* Skills match badge */}
                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center gap-1.5 flex-wrap text-xs">
                    <span className="text-slate-400 text-[11px]">Matched:</span>
                    {cand.matched_skills.map((s, idx) => (
                      <span key={idx} className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 font-semibold border border-emerald-200 text-[11px]">
                        ✓ {s}
                      </span>
                    ))}
                    {cand.missing_skills.length > 0 && (
                      <>
                        <span className="text-slate-400 text-[11px] ml-1">Missing:</span>
                        {cand.missing_skills.map((s, idx) => (
                          <span key={idx} className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 border border-slate-200 text-[11px]">
                            {s}
                          </span>
                        ))}
                      </>
                    )}
                  </div>
                </div>
              ))}

              {rankedCandidates.length === 0 && (
                <div className="text-center py-12 border border-dashed border-slate-300 rounded-2xl">
                  <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm font-bold text-slate-800">No student applicants for this drive yet</p>
                  <p className="text-xs text-slate-500 mt-1">Eligible campus students will appear here as they submit applications.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Post Job Modal */}
      {showPostJobModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Post New Placement Drive</h3>
                <p className="text-xs text-slate-500">Define role requirements, CGPA cutoff, and target skills</p>
              </div>
              <button
                onClick={() => setShowPostJobModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePostJob} className="p-6 overflow-y-auto space-y-4 flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Drive Title *</label>
                  <input
                    type="text"
                    required
                    value={jobForm.title}
                    onChange={e => setJobForm({ ...jobForm, title: e.target.value })}
                    placeholder="e.g. Software Development Engineer 2026"
                    className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Role / Designation *</label>
                  <input
                    type="text"
                    required
                    value={jobForm.role}
                    onChange={e => setJobForm({ ...jobForm, role: e.target.value })}
                    placeholder="e.g. SDE-1 / Cloud Systems"
                    className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Package CTC (LPA) *</label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    value={jobForm.package_lpa}
                    onChange={e => setJobForm({ ...jobForm, package_lpa: Number(e.target.value) })}
                    className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-bold text-indigo-700"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">CGPA Cutoff *</label>
                  <input
                    type="number"
                    step="0.1"
                    min={0}
                    max={10}
                    required
                    value={jobForm.cgpa_cutoff}
                    onChange={e => setJobForm({ ...jobForm, cgpa_cutoff: Number(e.target.value) })}
                    className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Deadline Date *</label>
                  <input
                    type="date"
                    required
                    value={jobForm.deadline}
                    onChange={e => setJobForm({ ...jobForm, deadline: e.target.value })}
                    className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Required Skills (comma separated) *
                </label>
                <input
                  type="text"
                  required
                  value={jobForm.required_skills}
                  onChange={e => setJobForm({ ...jobForm, required_skills: e.target.value })}
                  placeholder="C++, Python, React, Algorithms, SQL"
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Job Description</label>
                <textarea
                  rows={3}
                  value={jobForm.description}
                  onChange={e => setJobForm({ ...jobForm, description: e.target.value })}
                  placeholder="Responsibilities, qualification prerequisites, and interview rounds..."
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowPostJobModal(false)}
                  className="px-4 py-2 text-sm border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Publish Placement Drive
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Profile Edit Modal */}
      <EditProfileModal
        isOpen={showEditProfile}
        onClose={() => setShowEditProfile(false)}
        onProfileUpdated={loadDashboard}
      />
    </div>
  );
};
