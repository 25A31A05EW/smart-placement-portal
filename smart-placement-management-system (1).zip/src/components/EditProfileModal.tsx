import React, { useState, useEffect } from 'react';
import { X, Save, CheckCircle2, AlertCircle, Plus, Trash2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { StudentProfile, CompanyProfile, AdminProfile } from '../types';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProfileUpdated?: (updated: any) => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  onProfileUpdated
}) => {
  const { user, role, profile, updateProfileState } = useAuth();

  // Student state
  const [studentForm, setStudentForm] = useState({
    name: '',
    email: '',
    phone: '',
    branch: 'Computer Science and Engineering',
    semester: 8,
    cgpa: 8.0,
    skills: [] as string[],
    tenth_percentage: 90,
    twelfth_percentage: 90,
    backlogs: 0,
    bio: ''
  });
  const [newSkillInput, setNewSkillInput] = useState('');

  // Company state
  const [companyForm, setCompanyForm] = useState({
    company_name: '',
    email: '',
    phone: '',
    website: '',
    location: '',
    industry: '',
    description: ''
  });

  // Admin state
  const [adminForm, setAdminForm] = useState({
    name: '',
    email: '',
    designation: '',
    department: '',
    phone: ''
  });

  const [saving, setSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync initial values
  useEffect(() => {
    if (!isOpen) {
      setSuccessMessage(null);
      setErrorMessage(null);
      return;
    }

    if (role === 'student' && profile) {
      const s = profile as StudentProfile;
      setStudentForm({
        name: s.name || user?.name || '',
        email: s.email || user?.email || '',
        phone: s.phone || '',
        branch: s.branch || 'Computer Science and Engineering',
        semester: s.semester || 8,
        cgpa: s.cgpa || 8.0,
        skills: s.skills || ['C++', 'Python', 'Data Structures'],
        tenth_percentage: s.academic_info?.tenth_percentage ?? 90,
        twelfth_percentage: s.academic_info?.twelfth_percentage ?? 90,
        backlogs: s.academic_info?.backlogs ?? 0,
        bio: s.academic_info?.bio || ''
      });
    } else if (role === 'company' && profile) {
      const c = profile as CompanyProfile;
      setCompanyForm({
        company_name: c.company_name || user?.name || '',
        email: c.email || user?.email || '',
        phone: c.phone || '',
        website: c.website || '',
        location: c.location || '',
        industry: c.industry || 'Information Technology',
        description: c.description || ''
      });
    } else if (role === 'admin' && profile) {
      const a = profile as AdminProfile;
      setAdminForm({
        name: a.name || user?.name || '',
        email: a.email || user?.email || '',
        designation: a.designation || 'Placement Officer',
        department: a.department || 'Central Placement Cell',
        phone: a.phone || ''
      });
    }
  }, [isOpen, profile, role, user]);

  if (!isOpen) return null;

  const handleAddSkill = () => {
    if (!newSkillInput.trim()) return;
    if (!studentForm.skills.includes(newSkillInput.trim())) {
      setStudentForm(prev => ({
        ...prev,
        skills: [...prev.skills, newSkillInput.trim()]
      }));
    }
    setNewSkillInput('');
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setStudentForm(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== skillToRemove)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMessage(null);
    setErrorMessage(null);

    try {
      if (role === 'student') {
        if (!studentForm.name.trim() || !studentForm.email.trim()) {
          setErrorMessage('Name and Email are mandatory.');
          setSaving(false);
          return;
        }

        if (studentForm.cgpa < 0 || studentForm.cgpa > 10) {
          setErrorMessage('CGPA must be between 0.0 and 10.0');
          setSaving(false);
          return;
        }

        const res = await api.student.updateProfile({
          name: studentForm.name,
          email: studentForm.email,
          phone: studentForm.phone,
          branch: studentForm.branch,
          semester: Number(studentForm.semester),
          cgpa: Number(studentForm.cgpa),
          skills: studentForm.skills,
          academic_info: {
            tenth_percentage: Number(studentForm.tenth_percentage),
            twelfth_percentage: Number(studentForm.twelfth_percentage),
            backlogs: Number(studentForm.backlogs),
            bio: studentForm.bio
          }
        });

        if (res.success && res.data) {
          setSuccessMessage('Student profile updated successfully in database!');
          updateProfileState(res.data);
          onProfileUpdated?.(res.data);
          setTimeout(() => {
            onClose();
          }, 1200);
        } else {
          setErrorMessage(res.message || 'Failed to update student profile.');
        }
      } else if (role === 'company') {
        if (!companyForm.company_name.trim() || !companyForm.email.trim()) {
          setErrorMessage('Company Name and Email are mandatory.');
          setSaving(false);
          return;
        }

        const res = await api.company.updateProfile({
          company_name: companyForm.company_name,
          email: companyForm.email,
          phone: companyForm.phone,
          website: companyForm.website,
          location: companyForm.location,
          industry: companyForm.industry,
          description: companyForm.description
        });

        if (res.success && res.data) {
          setSuccessMessage('Company profile updated successfully in database!');
          updateProfileState(res.data);
          onProfileUpdated?.(res.data);
          setTimeout(() => {
            onClose();
          }, 1200);
        } else {
          setErrorMessage(res.message || 'Failed to update company profile.');
        }
      } else if (role === 'admin') {
        if (!adminForm.name.trim() || !adminForm.email.trim()) {
          setErrorMessage('Name and Email are mandatory.');
          setSaving(false);
          return;
        }

        const res = await api.admin.updateProfile({
          name: adminForm.name,
          email: adminForm.email,
          designation: adminForm.designation,
          department: adminForm.department,
          phone: adminForm.phone
        });

        if (res.success && res.data) {
          setSuccessMessage('Administrator profile updated successfully in database!');
          updateProfileState(res.data);
          onProfileUpdated?.(res.data);
          setTimeout(() => {
            onClose();
          }, 1200);
        } else {
          setErrorMessage(res.message || 'Failed to update admin profile.');
        }
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Network error occurred while saving profile.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Edit {role === 'student' ? 'Student' : role === 'company' ? 'Company' : 'Admin'} Profile
            </h2>
            <p className="text-xs text-slate-500">
              Update your registered credentials stored in the placement database
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-200/60 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <div className="p-6 overflow-y-auto flex-1">
          {successMessage && (
            <div className="mb-4 flex items-center gap-2 p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-sm font-medium animate-in fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="mb-4 flex items-center gap-2 p-3.5 bg-red-50 border border-red-200 text-red-800 rounded-xl text-sm font-medium animate-in fade-in">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {role === 'student' && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={studentForm.name}
                      onChange={e => setStudentForm({ ...studentForm, name: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={studentForm.email}
                      onChange={e => setStudentForm({ ...studentForm, email: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Phone Number
                    </label>
                    <input
                      type="text"
                      value={studentForm.phone}
                      onChange={e => setStudentForm({ ...studentForm, phone: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Branch / Department *
                    </label>
                    <select
                      value={studentForm.branch}
                      onChange={e => setStudentForm({ ...studentForm, branch: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    >
                      <option value="Computer Science and Engineering">Computer Science & Engg</option>
                      <option value="Information Technology">Information Technology</option>
                      <option value="Electronics and Communication">Electronics & Communication</option>
                      <option value="Electrical Engineering">Electrical Engineering</option>
                      <option value="Mechanical Engineering">Mechanical Engineering</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Semester (1-10) *
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={10}
                      required
                      value={studentForm.semester}
                      onChange={e => setStudentForm({ ...studentForm, semester: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Current CGPA (0.0 - 10.0) *
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min={0}
                      max={10}
                      required
                      value={studentForm.cgpa}
                      onChange={e => setStudentForm({ ...studentForm, cgpa: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-semibold text-indigo-700"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      10th Grade Percentage
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={studentForm.tenth_percentage}
                      onChange={e => setStudentForm({ ...studentForm, tenth_percentage: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      12th Grade Percentage
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={studentForm.twelfth_percentage}
                      onChange={e => setStudentForm({ ...studentForm, twelfth_percentage: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                {/* Skills Manager */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Technical Skills (Used in ADS Max-Heap Ranking)
                  </label>
                  <div className="flex gap-2 mb-2">
                    <input
                      type="text"
                      placeholder="e.g. C++, Python, React, SQL..."
                      value={newSkillInput}
                      onChange={e => setNewSkillInput(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddSkill();
                        }
                      }}
                      className="flex-1 px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                    <button
                      type="button"
                      onClick={handleAddSkill}
                      className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-medium text-xs rounded-lg transition flex items-center gap-1.5"
                    >
                      <Plus className="w-4 h-4" /> Add Skill
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5 p-2 bg-slate-50 border border-slate-200 rounded-lg min-h-12 items-center">
                    {studentForm.skills.map((skill, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center gap-1 px-2.5 py-1 bg-white border border-slate-300 text-slate-800 rounded-md text-xs font-medium shadow-2xs"
                      >
                        {skill}
                        <button
                          type="button"
                          onClick={() => handleRemoveSkill(skill)}
                          className="text-slate-400 hover:text-red-600 transition"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                    {studentForm.skills.length === 0 && (
                      <span className="text-xs text-slate-400 italic">No skills listed yet. Add skills to improve job matching.</span>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Candidate Bio / Career Objective
                  </label>
                  <textarea
                    rows={2}
                    value={studentForm.bio}
                    onChange={e => setStudentForm({ ...studentForm, bio: e.target.value })}
                    placeholder="Brief description of your technical interests and placement aspirations..."
                    className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
              </>
            )}

            {role === 'company' && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Company Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={companyForm.company_name}
                      onChange={e => setCompanyForm({ ...companyForm, company_name: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Official Contact Email *
                    </label>
                    <input
                      type="email"
                      required
                      value={companyForm.email}
                      onChange={e => setCompanyForm({ ...companyForm, email: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Contact Phone
                    </label>
                    <input
                      type="text"
                      value={companyForm.phone}
                      onChange={e => setCompanyForm({ ...companyForm, phone: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Industry Sector
                    </label>
                    <input
                      type="text"
                      value={companyForm.industry}
                      onChange={e => setCompanyForm({ ...companyForm, industry: e.target.value })}
                      placeholder="e.g. Cloud Software, FinTech"
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Primary Location
                    </label>
                    <input
                      type="text"
                      value={companyForm.location}
                      onChange={e => setCompanyForm({ ...companyForm, location: e.target.value })}
                      placeholder="e.g. Bengaluru / Remote"
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Careers Website
                  </label>
                  <input
                    type="url"
                    value={companyForm.website}
                    onChange={e => setCompanyForm({ ...companyForm, website: e.target.value })}
                    placeholder="https://company.com/careers"
                    className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Company Description & Mission
                  </label>
                  <textarea
                    rows={3}
                    value={companyForm.description}
                    onChange={e => setCompanyForm({ ...companyForm, description: e.target.value })}
                    placeholder="Describe your organization, work culture, and why campus students should join..."
                    className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
              </>
            )}

            {role === 'admin' && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Admin Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={adminForm.name}
                      onChange={e => setAdminForm({ ...adminForm, name: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Administrative Email *
                    </label>
                    <input
                      type="email"
                      required
                      value={adminForm.email}
                      onChange={e => setAdminForm({ ...adminForm, email: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Designation
                    </label>
                    <input
                      type="text"
                      value={adminForm.designation}
                      onChange={e => setAdminForm({ ...adminForm, designation: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Department
                    </label>
                    <input
                      type="text"
                      value={adminForm.department}
                      onChange={e => setAdminForm({ ...adminForm, department: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Contact Phone
                    </label>
                    <input
                      type="text"
                      value={adminForm.phone}
                      onChange={e => setAdminForm({ ...adminForm, phone: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>
              </>
            )}

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm border border-slate-200 text-slate-700 font-medium rounded-xl hover:bg-slate-100 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-5 py-2 text-sm bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl shadow-xs transition flex items-center gap-2 disabled:opacity-50"
              >
                {saving ? (
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Save className="w-4 h-4" />
                )}
                Save Profile Changes
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
