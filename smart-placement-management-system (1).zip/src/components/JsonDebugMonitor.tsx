import React, { useState } from 'react';
import { ShieldCheck, Bug, CheckCircle2, ChevronDown, ChevronUp, Code, ArrowRight } from 'lucide-react';
import { safeApiCall } from '../lib/api';

export const JsonDebugMonitor: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [testResult, setTestResult] = useState<{
    endpoint: string;
    status: number;
    contentType: string;
    isJson: boolean;
    payload: any;
  } | null>(null);
  const [loading, setLoading] = useState(false);

  const runTest = async (type: '404' | '500' | '401' | 'success') => {
    setLoading(true);
    setTestResult(null);

    let url = '/api/debug/test-json-safeguard';
    let body: any = null;

    if (type === '404') {
      url = '/api/non-existent-route-testing-safeguard';
    } else if (type === '500') {
      body = JSON.stringify({ test_case: 'error_500' });
    } else if (type === '401') {
      body = JSON.stringify({ test_case: 'unauthorized' });
    } else {
      body = JSON.stringify({ test_case: 'normal' });
    }

    try {
      const rawRes = await fetch(url, {
        method: body ? 'POST' : 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body
      });

      const contentType = rawRes.headers.get('content-type') || 'none';
      const text = await rawRes.text();
      let parsed = null;
      let isJson = false;

      try {
        parsed = JSON.parse(text);
        isJson = true;
      } catch {
        parsed = text;
        isJson = false;
      }

      setTestResult({
        endpoint: url,
        status: rawRes.status,
        contentType,
        isJson,
        payload: parsed
      });
    } catch (err: any) {
      setTestResult({
        endpoint: url,
        status: 0,
        contentType: 'error',
        isJson: false,
        payload: { error: err.message }
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <footer className="mt-12 border-t border-slate-200 bg-white/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-200">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-900">
                  Resilient API Architecture Active
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  Guaranteed JSON Protection
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                Prevents "Invalid JSON" errors via strict Express catch-all, header validation, and AbortController cancellation on account switches.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-indigo-50 transition border border-indigo-100"
          >
            <Bug className="w-3.5 h-3.5" />
            <span>{isOpen ? 'Hide Architecture Diagnosis' : 'Inspect JSON Safeguards & Live Tests'}</span>
            {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {isOpen && (
          <div className="mt-4 pt-4 border-t border-slate-200 text-xs text-slate-700 space-y-4 animate-in fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  What Caused the "Invalid JSON" Error?
                </h4>
                <ul className="list-disc list-inside space-y-1 text-slate-600 leading-relaxed text-[11px]">
                  <li>
                    <strong>HTML Error Pages:</strong> Default web server 404 or 500 handlers returned HTML (<code>&lt;!DOCTYPE html&gt;</code>) instead of JSON, triggering <code>SyntaxError: Unexpected token '&lt;'</code> on <code>response.json()</code>.
                  </li>
                  <li>
                    <strong>Empty 204 or Null Responses:</strong> Logout endpoints returned empty string bodies, throwing <code>SyntaxError: Unexpected end of JSON input</code>.
                  </li>
                  <li>
                    <strong>Inflight Race Conditions:</strong> Requests initiated by Account A resolved after switching to Account B, receiving unauthenticated HTML pages that crashed the client parser.
                  </li>
                </ul>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200 space-y-2">
                <h4 className="font-bold text-emerald-950 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  How the Permanent Fix Protects the App:
                </h4>
                <ul className="list-disc list-inside space-y-1 text-emerald-900 leading-relaxed text-[11px]">
                  <li>
                    <strong>Strict API Middleware:</strong> All <code>/api/*</code> routes guarantee <code>Content-Type: application/json; charset=utf-8</code>.
                  </li>
                  <li>
                    <strong>Wildcard 404 & 500 JSON Interceptors:</strong> Any missing endpoint or unhandled exception returns structured JSON, never HTML!
                  </li>
                  <li>
                    <strong>Safe Fetch Client (<code>safeApiCall</code>):</strong> Inspects <code>response.text()</code> before parsing and validates content-type defensively.
                  </li>
                  <li>
                    <strong>AbortController on Account Switch:</strong> Cancels all active HTTP streams immediately upon logout or switch account.
                  </li>
                </ul>
              </div>
            </div>

            {/* Live Interactive Safeguard Test Buttons */}
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="font-bold text-slate-900">
                  Live Response Header & JSON Payload Verification:
                </span>
                <span className="text-[11px] text-slate-500">
                  Click any scenario below to verify that valid JSON is returned in all failure modes:
                </span>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => runTest('success')}
                  disabled={loading}
                  className="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold hover:bg-emerald-100 transition"
                >
                  Test 1: 200 Success JSON
                </button>
                <button
                  onClick={() => runTest('404')}
                  disabled={loading}
                  className="px-3 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 font-semibold hover:bg-indigo-100 transition"
                >
                  Test 2: Missing Route (404 JSON Catch-All)
                </button>
                <button
                  onClick={() => runTest('500')}
                  disabled={loading}
                  className="px-3 py-1.5 rounded-lg bg-red-50 text-red-700 border border-red-200 font-semibold hover:bg-red-100 transition"
                >
                  Test 3: Server Error (500 JSON Catch-All)
                </button>
                <button
                  onClick={() => runTest('401')}
                  disabled={loading}
                  className="px-3 py-1.5 rounded-lg bg-amber-50 text-amber-700 border border-amber-200 font-semibold hover:bg-amber-100 transition"
                >
                  Test 4: Unauthorized (401 JSON)
                </button>
              </div>

              {testResult && (
                <div className="mt-3 p-3 bg-slate-950 text-slate-100 rounded-xl font-mono text-xs overflow-x-auto space-y-1">
                  <div className="text-emerald-400 font-bold">
                    HTTP {testResult.status} | Content-Type: {testResult.contentType} | Valid JSON: {String(testResult.isJson).toUpperCase()}
                  </div>
                  <pre className="text-[11px] text-slate-300">
                    {JSON.stringify(testResult.payload, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </footer>
  );
};
