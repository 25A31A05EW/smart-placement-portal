import React, { useState } from 'react';
import {
  GraduationCap,
  Building2,
  ShieldCheck,
  LogOut,
  UserCheck,
  ChevronDown,
  UserPlus,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { SignOutConfirmModal } from './SignOutConfirmModal';
import { EditProfileModal } from './EditProfileModal';

interface NavbarProps {
  onOpenAuthModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = () => {
  const { user, role, profile, logout, switchAccount } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [showSignOutConfirm, setShowSignOutConfirm] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);

  const getRoleBadge = () => {
    switch (role) {
      case 'student':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <GraduationCap className="w-3.5 h-3.5 text-emerald-600" /> Student
          </span>
        );
      case 'company':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <Building2 className="w-3.5 h-3.5 text-blue-600" /> Recruiter
          </span>
        );
      case 'admin':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
            <ShieldCheck className="w-3.5 h-3.5 text-purple-600" /> Placement Cell Admin
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Brand Logo & Name */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-200">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                    Smart Placement Portal
                  </h1>
                  <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded-md border border-indigo-100">
                    <Sparkles className="w-3 h-3 text-indigo-500" /> C++17 & ADS Core
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 hidden sm:block">
                  Automated campus recruitment, Max-Heap candidate ranking & resilient session switcher
                </p>
              </div>
            </div>

            {/* Right actions */}
            <div className="flex items-center gap-3">
              {user ? (
                <div className="flex items-center gap-2">
                  {/* Role pill */}
                  <div className="hidden sm:block">{getRoleBadge()}</div>

                  {/* Switch Account Quick Action Button */}
                  <button
                    onClick={switchAccount}
                    title="Safely end session and sign in with a different user"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-indigo-200 bg-indigo-50/70 hover:bg-indigo-100/70 text-indigo-700 text-xs font-semibold transition"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span className="hidden md:inline">Switch Account</span>
                  </button>

                  {/* User Profile & Actions Dropdown */}
                  <div className="relative">
                    <button
                      onClick={() => setDropdownOpen(!dropdownOpen)}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition text-left"
                    >
                      <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs">
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="hidden lg:block text-left">
                        <div className="text-xs font-bold text-slate-900 truncate max-w-[130px]">
                          {user.name}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate max-w-[130px]">
                          {user.email}
                        </div>
                      </div>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                    </button>

                    {dropdownOpen && (
                      <div
                        className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95"
                        onMouseLeave={() => setDropdownOpen(false)}
                      >
                        <div className="px-4 py-2 border-b border-slate-100">
                          <p className="text-xs font-bold text-slate-900">{user.name}</p>
                          <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                          <div className="mt-1.5">{getRoleBadge()}</div>
                        </div>

                        <div className="py-1">
                          <button
                            onClick={() => {
                              setDropdownOpen(false);
                              setShowEditProfile(true);
                            }}
                            className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 transition"
                          >
                            <UserCheck className="w-4 h-4 text-indigo-600" />
                            Edit Profile Details
                          </button>

                          <button
                            onClick={() => {
                              setDropdownOpen(false);
                              switchAccount();
                            }}
                            className="w-full text-left px-4 py-2 text-xs font-medium text-indigo-700 hover:bg-indigo-50 flex items-center gap-2.5 transition"
                          >
                            <RefreshCw className="w-4 h-4 text-indigo-600" />
                            Switch Account
                          </button>
                        </div>

                        <div className="border-t border-slate-100 pt-1">
                          <button
                            onClick={() => {
                              setDropdownOpen(false);
                              setShowSignOutConfirm(true);
                            }}
                            className="w-full text-left px-4 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 flex items-center gap-2.5 transition"
                          >
                            <LogOut className="w-4 h-4 text-red-500" />
                            Sign Out
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Clearly visible Sign Out button in navigation menu */}
                  <button
                    onClick={() => setShowSignOutConfirm(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 bg-red-50/60 hover:bg-red-100/80 text-red-700 text-xs font-semibold transition"
                    title="Sign out of current account"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Sign Out</span>
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                    <UserPlus className="w-4 h-4 text-indigo-600" />
                    Please sign in or select an account below
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Sign Out Confirmation Modal */}
      <SignOutConfirmModal
        isOpen={showSignOutConfirm}
        onClose={() => setShowSignOutConfirm(false)}
        onConfirm={logout}
        userName={user?.name}
        role={role || undefined}
      />

      {/* Edit Profile Modal */}
      <EditProfileModal
        isOpen={showEditProfile}
        onClose={() => setShowEditProfile(false)}
      />
    </>
  );
};
