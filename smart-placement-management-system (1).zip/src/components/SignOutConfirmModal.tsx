import React from 'react';
import { LogOut, AlertTriangle, X } from 'lucide-react';

interface SignOutConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  userName?: string;
  role?: string;
}

export const SignOutConfirmModal: React.FC<SignOutConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  userName,
  role
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="p-6">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3.5 mb-4">
            <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
              <LogOut className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900">Sign Out Confirmation</h3>
              <p className="text-xs text-slate-500">Session termination & secure handover</p>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-xl p-3.5 mb-5 text-sm text-slate-700">
            <p className="mb-2">
              Are you sure you want to sign out of <span className="font-semibold text-slate-900">{userName || 'your account'}</span> ({role || 'Active User'})?
            </p>
            <div className="flex items-start gap-2 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg p-2.5">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
              <span>
                <strong>Your records remain intact:</strong> All registration details, application records, and profile edits are safely saved in the placement database.
              </span>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-medium hover:bg-slate-100 text-sm transition"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                onConfirm();
                onClose();
              }}
              className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-medium text-sm transition shadow-xs flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Confirm Sign Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
