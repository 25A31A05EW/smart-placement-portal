import React, { useState, useEffect, useCallback } from 'react';
import {
  GraduationCap,
  Briefcase,
  CheckCircle2,
  Clock,
  AlertCircle,
  Building2,
  MapPin,
  Calendar,
  Sparkles,
  UserCheck,
  Send,
  RefreshCw,
  Award,
  ChevronRight,
  Code
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { StudentProfile, JobDrive, Application } from '../types';
import { EditProfileModal } from './EditProfileModal';

export const StudentDashboard: React.FC = () => {
  const { user } = useAuth();
  const [student, setStudent] = useState<StudentProfile | null>(null);
  const [jobs, setJobs] = useState<Array<JobDrive & {
    is_applied: boolean;
    is_eligible: boolean;
    cgpa_ok: boolean;
    branch_ok: boolean;
    matched_skills: string[];
    skill_match_percent: number;
  }>>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [stats, setStats] = useState({ total_applied: 0, shortlisted: 0, interviews: 0, offers: 0 });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [applyingJobId, setApplyingJobId] = useState<number | null>(null);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [activeTab, setActiveTab] = useState<'drives' | 'applications'>('drives');

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.student.getDashboard();
      if (res.success && res.data) {
        setStudent(res.data.student);
        setJobs(res.data.jobs);
        setApplications(res.data.applications);
        setStats(res.data.stats);
      } else {
        setError(res.message || 'Failed to load student dashboard.');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred while loading student dashboard.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  const handleApply = async (jobId: number) => {
    setApplyingJobId(jobId);
    setActionSuccess(null);
    setError(null);

    try {
      const res = await api.student.applyForJob(jobId);
      if (res.success) {
        setActionSuccess('Application submitted successfully! Your profile passed automated criteria checks.');
        // Refresh dashboard data
        await loadDashboard();
      } else {
        setError(res.message || 'Failed to apply for drive.');
      }
    } catch (err: any) {
      setError(err.message || 'Application request failed.');
    } finally {
      setApplyingJobId(null);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'offered':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <Award className="w-3.5 h-3.5 text-emerald-700" /> Offer Extended
          </span>
        );
      case 'interview':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300">
            <Clock className="w-3.5 h-3.5 text-amber-700" /> Interview Scheduled
          </span>
        );
      case 'shortlisted':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-700" /> Shortlisted
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-800 border border-red-300">
            <AlertCircle className="w-3.5 h-3.5 text-red-700" /> Application Closed
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-800 border border-slate-300">
            <Clock className="w-3.5 h-3.5 text-slate-600" /> Under Review
          </span>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Welcome & Profile Summary Banner */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 sm:p-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-white flex items-center justify-center font-bold text-2xl shadow-md shadow-emerald-200 shrink-0">
              <GraduationCap className="w-9 h-9" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  {student?.name || user?.name}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Semester {student?.semester || 8}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  CGPA {student?.cgpa?.toFixed(2) || '0.00'} / 10.0
                </span>
              </div>
              <p className="text-sm text-slate-600 mt-1">
                {student?.branch || 'Computer Science and Engineering'} • {student?.email || user?.email}
              </p>
              <div className="flex items-center gap-1.5 mt-3 flex-wrap">
                <span className="text-xs font-semibold text-slate-500 mr-1 flex items-center gap-1">
                  <Code className="w-3.5 h-3.5 text-indigo-500" /> Skills:
                </span>
                {student?.skills?.map((s, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700 text-xs font-medium border border-slate-200"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 self-start md:self-center shrink-0">
            <button
              onClick={() => setShowEditProfile(true)}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-2"
            >
              <UserCheck className="w-4 h-4" />
              Edit Student Profile
            </button>
            <button
              onClick={loadDashboard}
              title="Refresh placement drives"
              className="p-2.5 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl transition"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8 pt-6 border-t border-slate-100">
          <div className="p-4 rounded-2xl bg-slate-50/70 border border-slate-200/70">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Applied Drives</p>
            <p className="text-2xl font-bold text-slate-900 mt-1">{stats.total_applied}</p>
          </div>
          <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200/70">
            <p className="text-xs font-semibold text-blue-600 uppercase tracking-wider">Shortlisted</p>
            <p className="text-2xl font-bold text-blue-900 mt-1">{stats.shortlisted}</p>
          </div>
          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/70">
            <p className="text-xs font-semibold text-amber-600 uppercase tracking-wider">Interviews</p>
            <p className="text-2xl font-bold text-amber-900 mt-1">{stats.interviews}</p>
          </div>
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/70">
            <p className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">Job Offers</p>
            <p className="text-2xl font-bold text-emerald-900 mt-1">{stats.offers}</p>
          </div>
        </div>
      </div>

      {/* Notifications */}
      {actionSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-sm flex items-center gap-3 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-800 rounded-2xl text-sm flex items-center gap-3 animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-6">
        <button
          onClick={() => setActiveTab('drives')}
          className={`pb-3 text-sm font-bold flex items-center gap-2 border-b-2 transition ${
            activeTab === 'drives'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          Eligible Campus Placement Drives ({jobs.length})
        </button>

        <button
          onClick={() => setActiveTab('applications')}
          className={`pb-3 text-sm font-bold flex items-center gap-2 border-b-2 transition ${
            activeTab === 'applications'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          My Application Statuses ({applications.length})
        </button>
      </div>

      {/* TAB CONTENT: DRIVES */}
      {activeTab === 'drives' && (
        <div className="space-y-4">
          {jobs.map(job => (
            <div
              key={job.id}
              className={`p-6 rounded-3xl border bg-white shadow-xs transition hover:shadow-md ${
                job.is_applied ? 'border-slate-200 bg-slate-50/40' : job.is_eligible ? 'border-indigo-200' : 'border-slate-200 opacity-80'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="px-3 py-1 rounded-xl text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                      {job.package_lpa} LPA Package
                    </span>
                    <span className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                      <Building2 className="w-4 h-4 text-slate-400" />
                      {job.company_name}
                    </span>
                    <span className="text-xs text-slate-500 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {job.location}
                    </span>
                    <span className="text-xs text-slate-500 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      Deadline: {job.deadline}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900">{job.title}</h3>
                  <p className="text-xs text-slate-600 max-w-3xl leading-relaxed">{job.description}</p>

                  {/* ADS Eligibility Breakdown */}
                  <div className="pt-2 flex items-center gap-3 flex-wrap text-xs">
                    <div className="flex items-center gap-1">
                      <span className="text-slate-500">CGPA Cutoff:</span>
                      <span className="font-semibold text-slate-800">{job.cgpa_cutoff}</span>
                      {job.cgpa_ok ? (
                        <span className="text-emerald-600 font-bold ml-1">✓ Eligible</span>
                      ) : (
                        <span className="text-red-500 font-bold ml-1">✗ Below Cutoff</span>
                      )}
                    </div>

                    <div className="h-3 w-px bg-slate-200" />

                    <div className="flex items-center gap-1">
                      <span className="text-slate-500">Branch:</span>
                      {job.branch_ok ? (
                        <span className="text-emerald-600 font-bold">✓ Allowed</span>
                      ) : (
                        <span className="text-red-500 font-bold">✗ Not Eligible</span>
                      )}
                    </div>

                    <div className="h-3 w-px bg-slate-200" />

                    <div className="flex items-center gap-1">
                      <span className="text-slate-500">Skill Match:</span>
                      <span className={`font-bold px-2 py-0.5 rounded-md ${
                        job.skill_match_percent >= 60
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}>
                        {job.skill_match_percent}% match ({job.matched_skills.length}/{job.required_skills.length})
                      </span>
                    </div>
                  </div>

                  {/* Skills tags */}
                  <div className="flex items-center gap-1.5 flex-wrap pt-1">
                    {job.required_skills.map((skill, sIdx) => {
                      const matched = job.matched_skills.includes(skill);
                      return (
                        <span
                          key={sIdx}
                          className={`text-[11px] px-2 py-0.5 rounded-md font-medium ${
                            matched
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold'
                              : 'bg-slate-100 text-slate-600 border border-slate-200'
                          }`}
                        >
                          {matched ? '✓ ' : ''}{skill}
                        </span>
                      );
                    })}
                  </div>
                </div>

                {/* Right Action */}
                <div className="flex items-center gap-3 shrink-0 self-start lg:self-center">
                  {job.is_applied ? (
                    <div className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 border border-slate-200 text-xs font-semibold flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Applied
                    </div>
                  ) : job.is_eligible ? (
                    <button
                      onClick={() => handleApply(job.id)}
                      disabled={applyingJobId === job.id}
                      className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-200 transition flex items-center gap-2 disabled:opacity-50"
                    >
                      {applyingJobId === job.id ? (
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          Apply Now
                        </>
                      )}
                    </button>
                  ) : (
                    <span className="px-3.5 py-2 rounded-xl bg-red-50 text-red-700 border border-red-200 text-xs font-semibold">
                      Criteria Not Met
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}

          {jobs.length === 0 && !loading && (
            <div className="text-center py-12 bg-white rounded-3xl border border-slate-200">
              <Briefcase className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-slate-900">No active placement drives found</h3>
              <p className="text-xs text-slate-500 mt-1">Check back soon as recruitment partners post new positions.</p>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: APPLICATIONS */}
      {activeTab === 'applications' && (
        <div className="space-y-4">
          {applications.map(app => (
            <div
              key={app.id}
              className="p-6 rounded-3xl border border-slate-200 bg-white shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <span className="text-base font-bold text-slate-900">{app.job_title}</span>
                  <span className="text-xs text-slate-500 font-semibold">• {app.company_name}</span>
                </div>
                <div className="text-xs text-slate-500 flex items-center gap-4 flex-wrap">
                  <span>Package: <strong className="text-slate-800">{app.package_lpa} LPA</strong></span>
                  <span>Applied On: <strong className="text-slate-800">{new Date(app.applied_at).toLocaleDateString()}</strong></span>
                  {app.notes && (
                    <span className="italic text-slate-600 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-200">
                      Recruiter Note: {app.notes}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-3">
                {getStatusBadge(app.status)}
              </div>
            </div>
          ))}

          {applications.length === 0 && (
            <div className="text-center py-12 bg-white rounded-3xl border border-slate-200">
              <CheckCircle2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-slate-900">No applications submitted yet</h3>
              <p className="text-xs text-slate-500 mt-1">Review the active drives tab above and apply for positions matching your profile.</p>
            </div>
          )}
        </div>
      )}

      {/* Profile Edit Modal */}
      <EditProfileModal
        isOpen={showEditProfile}
        onClose={() => setShowEditProfile(false)}
        onProfileUpdated={loadDashboard}
      />
    </div>
  );
};
