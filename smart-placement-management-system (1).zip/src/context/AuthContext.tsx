import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, UserRole, StudentProfile, CompanyProfile, AdminProfile } from '../types';
import { api, getStoredToken, getStoredUser, setStoredSession, clearStoredSession, abortInflightRequests } from '../lib/api';

interface AuthContextType {
  user: User | null;
  role: UserRole | null;
  profile: StudentProfile | CompanyProfile | AdminProfile | null;
  loading: boolean;
  switchingAccount: boolean;
  error: string | null;
  login: (email: string, password: string, role?: UserRole) => Promise<{ success: boolean; message: string }>;
  register: (payload: any) => Promise<{ success: boolean; message: string }>;
  logout: () => Promise<void>;
  switchAccount: () => void;
  refreshSession: () => Promise<void>;
  updateProfileState: (updated: any) => void;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => getStoredUser());
  const [role, setRole] = useState<UserRole | null>(() => getStoredUser()?.role || null);
  const [profile, setProfile] = useState<StudentProfile | CompanyProfile | AdminProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [switchingAccount, setSwitchingAccount] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Validate session on mount
  const refreshSession = useCallback(async () => {
    const token = getStoredToken();
    if (!token) {
      setUser(null);
      setRole(null);
      setProfile(null);
      setLoading(false);
      return;
    }

    try {
      const res = await api.auth.getSession();
      if (res.success && res.data) {
        setUser(res.data.user);
        setRole(res.data.user.role);
        setProfile(res.data.profile);
        setError(null);
      } else {
        // Expired or invalid token: clean up without crashing
        console.warn('Session verification failed:', res.message);
        clearStoredSession();
        setUser(null);
        setRole(null);
        setProfile(null);
      }
    } catch (err: any) {
      console.error('Error refreshing session:', err);
      clearStoredSession();
      setUser(null);
      setRole(null);
      setProfile(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSession();
  }, [refreshSession]);

  const login = async (email: string, password: string, roleParam?: UserRole): Promise<{ success: boolean; message: string }> => {
    setError(null);
    setLoading(true);

    // Cancel any previous requests
    abortInflightRequests();

    try {
      const res = await api.auth.login(email, password, roleParam);
      if (res.success && res.data) {
        const { token, user: loggedUser, profile: loggedProfile } = res.data;
        setStoredSession(token, loggedUser);
        setUser(loggedUser);
        setRole(loggedUser.role);
        setProfile(loggedProfile);
        setSwitchingAccount(false);
        return { success: true, message: res.message || 'Login successful' };
      } else {
        const msg = res.message || 'Authentication failed. Please verify your credentials.';
        setError(msg);
        return { success: false, message: msg };
      }
    } catch (err: any) {
      const msg = err.message || 'An unexpected error occurred during login.';
      setError(msg);
      return { success: false, message: msg };
    } finally {
      setLoading(false);
    }
  };

  const register = async (payload: any): Promise<{ success: boolean; message: string }> => {
    setError(null);
    setLoading(true);
    abortInflightRequests();

    try {
      const res = await api.auth.register(payload);
      if (res.success && res.data) {
        const { token, user: newUser } = res.data;
        setStoredSession(token, newUser);
        setUser(newUser);
        setRole(newUser.role);
        // Refresh full profile data
        await refreshSession();
        return { success: true, message: res.message || 'Registration completed successfully' };
      } else {
        const msg = res.message || 'Registration failed. Please check the provided information.';
        setError(msg);
        return { success: false, message: msg };
      }
    } catch (err: any) {
      const msg = err.message || 'An unexpected registration error occurred.';
      setError(msg);
      return { success: false, message: msg };
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    // 1. Immediately abort inflight requests
    abortInflightRequests();
    // 2. Clear token & local storage
    clearStoredSession();
    // 3. Reset all React states
    setUser(null);
    setRole(null);
    setProfile(null);
    setError(null);
    setSwitchingAccount(false);
    // 4. Invalidate on server
    try {
      await api.auth.logout();
    } catch (e) {
      console.warn('Server logout notification failed, cleared locally:', e);
    }
  };

  const switchAccount = () => {
    // Dedicated Switch Account implementation:
    // 1. Abort any pending background tasks
    abortInflightRequests();
    // 2. Invalidate server session & storage
    clearStoredSession();
    // 3. Clear existing user profile & state
    setUser(null);
    setRole(null);
    setProfile(null);
    setError(null);
    // 4. Mark switching flag so UI can focus on login / quick switch
    setSwitchingAccount(true);
  };

  const updateProfileState = (updated: any) => {
    setProfile(updated);
    if (updated.name && user) {
      setUser({ ...user, name: updated.name });
    }
  };

  const clearError = () => setError(null);

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        profile,
        loading,
        switchingAccount,
        error,
        login,
        register,
        logout,
        switchAccount,
        refreshSession,
        updateProfileState,
        clearError
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
