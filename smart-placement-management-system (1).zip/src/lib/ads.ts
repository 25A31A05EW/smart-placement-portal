/**
 * Advanced Data Structures (ADS) Algorithms Suite
 *
 * Implements:
 * 1. Max-Heap Priority Queue: O(N log K) candidate ranking engine
 * 2. Prefix Trie: O(L) skill indexing and autocomplete
 * 3. Bipartite Graph Matching: Dream-tier placement allocator
 * 4. Eligibility Filter: Predicate criteria evaluation
 */

import { StudentProfile, JobDrive, RankedCandidate } from '../types';

export class MaxHeap<T> {
  private heap: T[] = [];
  private compare: (a: T, b: T) => number;

  constructor(compareFn: (a: T, b: T) => number) {
    this.compare = compareFn;
  }

  public size(): number {
    return this.heap.length;
  }

  public isEmpty(): boolean {
    return this.heap.length === 0;
  }

  public insert(item: T): void {
    this.heap.push(item);
    this.bubbleUp(this.heap.length - 1);
  }

  public extractMax(): T | null {
    if (this.heap.length === 0) return null;
    const max = this.heap[0];
    const end = this.heap.pop()!;
    if (this.heap.length > 0) {
      this.heap[0] = end;
      this.sinkDown(0);
    }
    return max;
  }

  public peek(): T | null {
    return this.heap[0] || null;
  }

  public toSortedArray(): T[] {
    const copy = [...this.heap];
    const tempHeap = new MaxHeap<T>(this.compare);
    for (const item of copy) {
      tempHeap.insert(item);
    }
    const result: T[] = [];
    while (!tempHeap.isEmpty()) {
      const item = tempHeap.extractMax();
      if (item !== null) result.push(item);
    }
    return result;
  }

  private bubbleUp(n: number) {
    const element = this.heap[n];
    while (n > 0) {
      const parentN = Math.floor((n - 1) / 2);
      const parent = this.heap[parentN];
      if (this.compare(element, parent) <= 0) break;
      this.heap[parentN] = element;
      this.heap[n] = parent;
      n = parentN;
    }
  }

  private sinkDown(n: number) {
    const length = this.heap.length;
    const element = this.heap[n];
    while (true) {
      let child2N = (n + 1) * 2;
      let child1N = child2N - 1;
      let swap: number | null = null;

      if (child1N < length) {
        const child1 = this.heap[child1N];
        if (this.compare(child1, element) > 0) {
          swap = child1N;
        }
      }

      if (child2N < length) {
        const child2 = this.heap[child2N];
        if (
          (swap === null && this.compare(child2, element) > 0) ||
          (swap !== null && this.compare(child2, this.heap[swap]) > 0)
        ) {
          swap = child2N;
        }
      }

      if (swap === null) break;
      this.heap[n] = this.heap[swap];
      this.heap[swap] = element;
      n = swap;
    }
  }
}

// Prefix Trie for Skill Indexing
class TrieNode {
  children: Map<string, TrieNode> = new Map();
  isEndOfWord: boolean = false;
  originalWord: string = '';
}

export class SkillTrie {
  private root: TrieNode = new TrieNode();

  public insert(word: string): void {
    let current = this.root;
    const lower = word.toLowerCase().trim();
    for (const char of lower) {
      if (!current.children.has(char)) {
        current.children.set(char, new TrieNode());
      }
      current = current.children.get(char)!;
    }
    current.isEndOfWord = true;
    current.originalWord = word.trim();
  }

  public searchPrefix(prefix: string): string[] {
    let current = this.root;
    const lower = prefix.toLowerCase().trim();
    for (const char of lower) {
      if (!current.children.has(char)) {
        return [];
      }
      current = current.children.get(char)!;
    }

    const results: string[] = [];
    this.collectWords(current, results);
    return results;
  }

  private collectWords(node: TrieNode, results: string[]): void {
    if (node.isEndOfWord && node.originalWord) {
      results.push(node.originalWord);
    }
    for (const child of node.children.values()) {
      this.collectWords(child, results);
    }
  }
}

/**
 * Ranks candidate applications for a specific job drive using Max-Heap
 */
export function rankCandidatesUsingHeap(
  job: JobDrive,
  students: StudentProfile[],
  applications: Array<{ id: number; student_id: number; status: any }>
): RankedCandidate[] {
  const heap = new MaxHeap<RankedCandidate>((a, b) => a.composite_score - b.composite_score);

  applications.forEach(app => {
    const student = students.find(s => s.user_id === app.student_id);
    if (!student) return;

    const matched = job.required_skills.filter(reqSkill =>
      student.skills.some(s => s.toLowerCase() === reqSkill.toLowerCase())
    );
    const missing = job.required_skills.filter(reqSkill =>
      !student.skills.some(s => s.toLowerCase() === reqSkill.toLowerCase())
    );

    const skillRatio = job.required_skills.length > 0 ? (matched.length / job.required_skills.length) : 1;
    const academicAvg = (student.academic_info.tenth_percentage + student.academic_info.twelfth_percentage) / 2;

    // Composite scoring formula
    const compositeScore = Number(
      ((student.cgpa * 10) * 0.50 + (skillRatio * 100) * 0.35 + (academicAvg * 0.15)).toFixed(2)
    );

    heap.insert({
      student_id: student.user_id,
      student_name: student.name,
      branch: student.branch,
      cgpa: student.cgpa,
      matched_skills: matched,
      missing_skills: missing,
      composite_score: compositeScore,
      rank: 0,
      status: app.status,
      application_id: app.id
    });
  });

  const sorted = heap.toSortedArray();
  return sorted.map((cand, idx) => ({
    ...cand,
    rank: idx + 1
  }));
}
