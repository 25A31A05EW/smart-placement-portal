/**
 * Smart Placement Management System - Resilient Safe API Client
 *
 * Implements ironclad defenses against "Invalid JSON" errors:
 * 1. Checks HTTP response status and statusText before parsing
 * 2. Validates Content-Type header explicitly for 'application/json'
 * 3. Safely extracts response text first to handle empty responses (e.g. 204 No Content)
 * 4. Traps JSON parse syntax exceptions with clear human-readable explanations
 * 5. Supports AbortController cancellation so stale inflight requests on account switch are killed
 * 6. Validates localStorage payloads with fail-safe recovery from corrupted state
 */

import { ApiResponse, User, UserRole, StudentProfile, CompanyProfile, AdminProfile, JobDrive, Application, RankedCandidate } from '../types';

const SESSION_TOKEN_KEY = 'spms_session_token';
const SESSION_USER_KEY = 'spms_session_user';

// In-flight abort controller for current active account session
let activeAbortController: AbortController | null = null;

export function getActiveAbortSignal(): AbortSignal {
  if (!activeAbortController) {
    activeAbortController = new AbortController();
  }
  return activeAbortController.signal;
}

export function abortInflightRequests() {
  if (activeAbortController) {
    activeAbortController.abort();
    activeAbortController = new AbortController();
  }
}

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(SESSION_TOKEN_KEY) || null;
  } catch {
    return null;
  }
}

export function setStoredSession(token: string, user: User) {
  try {
    localStorage.setItem(SESSION_TOKEN_KEY, token);
    localStorage.setItem(SESSION_USER_KEY, JSON.stringify(user));
  } catch (e) {
    console.error('Failed to save session to localStorage:', e);
  }
}

export function getStoredUser(): User | null {
  try {
    const raw = localStorage.getItem(SESSION_USER_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.id && parsed.email && parsed.role) {
      return parsed as User;
    }
    return null;
  } catch {
    localStorage.removeItem(SESSION_USER_KEY);
    return null;
  }
}

export function clearStoredSession() {
  // Abort any pending requests from the old user
  abortInflightRequests();
  try {
    localStorage.removeItem(SESSION_TOKEN_KEY);
    localStorage.removeItem(SESSION_USER_KEY);
    sessionStorage.clear();
  } catch (e) {
    console.error('Error clearing stored session:', e);
  }
}

interface RequestOptions extends RequestInit {
  timeoutMs?: number;
}

/**
 * Ironclad API Fetcher with defensive JSON handling
 */
export async function safeApiCall<T = any>(
  endpoint: string,
  options: RequestOptions = {}
): Promise<ApiResponse<T>> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Accept': 'application/json',
    ...(options.headers as Record<string, string> || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
    headers['x-session-token'] = token;
  }

  // Ensure JSON Content-Type for requests with body if not set
  if (options.body && typeof options.body === 'string' && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json; charset=utf-8';
  }

  const signal = options.signal || getActiveAbortSignal();

  try {
    const response = await fetch(endpoint, {
      ...options,
      headers,
      signal
    });

    const contentType = response.headers.get('content-type') || '';
    const rawText = await response.text();

    // Handle empty response body gracefully without crashing JSON parser
    if (!rawText || rawText.trim() === '') {
      if (response.ok) {
        return {
          success: true,
          message: 'Operation completed successfully (empty body)',
          data: null
        };
      } else {
        return {
          success: false,
          message: `Server returned HTTP ${response.status} with empty response body.`,
          data: null
        };
      }
    }

    // Defensive check: is the response HTML instead of JSON?
    const isHtml = contentType.includes('text/html') || rawText.trim().startsWith('<!DOCTYPE') || rawText.trim().startsWith('<html');
    if (isHtml) {
      return {
        success: false,
        message: `Unexpected HTML response from server (HTTP ${response.status}). Expected application/json. Endpoint: ${endpoint}`,
        data: null
      };
    }

    // Attempt safe JSON parse with full diagnostic catch
    let parsed: any;
    try {
      parsed = JSON.parse(rawText);
    } catch (parseError: any) {
      console.error('JSON Parse Failure on endpoint:', endpoint, 'Raw content:', rawText.slice(0, 200));
      return {
        success: false,
        message: `Invalid JSON response received: ${parseError.message}. Safe fallback engaged.`,
        data: null
      };
    }

    // If server sent structured response matching our format
    if (parsed && typeof parsed === 'object' && typeof parsed.success === 'boolean') {
      return parsed as ApiResponse<T>;
    }

    // Normalizing non-standard responses into consistent schema
    if (response.ok) {
      return {
        success: true,
        message: 'Success',
        data: parsed as T
      };
    } else {
      return {
        success: false,
        message: parsed?.message || parsed?.error || `Request failed with HTTP status ${response.status}`,
        data: null
      };
    }
  } catch (error: any) {
    if (error.name === 'AbortError') {
      return {
        success: false,
        message: 'Request was cancelled due to account switch or navigation.',
        data: null
      };
    }

    console.warn(`Network or API call exception for ${endpoint}:`, error.message);
    return {
      success: false,
      message: error.message || 'Network connection failed. Please check your connectivity.',
      data: null
    };
  }
}

// -------------------------------------------------------------
// TYPED API WRAPPER METHODS
// -------------------------------------------------------------

export const api = {
  auth: {
    login: async (email: string, password: string, role?: UserRole) => {
      // Always abort any stale background requests before authenticating a new user
      abortInflightRequests();
      return safeApiCall<{ token: string; user: User; profile: any }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password, role })
      });
    },

    register: async (payload: {
      email: string;
      password: string;
      role: UserRole;
      name: string;
      phone?: string;
      branch?: string;
      cgpa?: number;
      semester?: number;
      company_name?: string;
    }) => {
      abortInflightRequests();
      return safeApiCall<{ token: string; user: User }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    },

    logout: async () => {
      try {
        const res = await safeApiCall<{ logged_out: boolean }>('/api/auth/logout', {
          method: 'POST'
        });
        clearStoredSession();
        return res;
      } catch {
        clearStoredSession();
        return { success: true, message: 'Logged out locally', data: { logged_out: true } };
      }
    },

    getSession: async () => {
      return safeApiCall<{ user: User; profile: any }>('/api/auth/session', {
        method: 'GET'
      });
    }
  },

  student: {
    getDashboard: async () => {
      return safeApiCall<{
        student: StudentProfile;
        applications: Application[];
        jobs: Array<JobDrive & { is_applied: boolean; is_eligible: boolean; cgpa_ok: boolean; branch_ok: boolean; matched_skills: string[]; skill_match_percent: number }>;
        stats: { total_applied: number; shortlisted: number; interviews: number; offers: number };
      }>('/api/student/dashboard', { method: 'GET' });
    },

    updateProfile: async (data: Partial<StudentProfile>) => {
      return safeApiCall<StudentProfile>('/api/student/profile', {
        method: 'PUT',
        body: JSON.stringify(data)
      });
    },

    applyForJob: async (jobId: number) => {
      return safeApiCall<Application>('/api/applications/apply', {
        method: 'POST',
        body: JSON.stringify({ job_id: jobId })
      });
    }
  },

  company: {
    getDashboard: async () => {
      return safeApiCall<{
        company: CompanyProfile;
        jobs: JobDrive[];
        applications: Application[];
        stats: { total_drives: number; total_applicants: number; shortlisted: number; interviewed: number; offered: number };
      }>('/api/company/dashboard', { method: 'GET' });
    },

    updateProfile: async (data: Partial<CompanyProfile>) => {
      return safeApiCall<CompanyProfile>('/api/company/profile', {
        method: 'PUT',
        body: JSON.stringify(data)
      });
    },

    postJob: async (job: {
      title: string;
      role: string;
      package_lpa: number;
      cgpa_cutoff: number;
      eligible_branches: string[];
      required_skills: string[];
      location: string;
      deadline: string;
      description: string;
    }) => {
      return safeApiCall<JobDrive>('/api/jobs', {
        method: 'POST',
        body: JSON.stringify(job)
      });
    },

    updateApplicationStatus: async (applicationId: number, status: string, notes?: string) => {
      return safeApiCall<Application>(`/api/applications/${applicationId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status, notes })
      });
    },

    getRankings: async (jobId: number) => {
      return safeApiCall<{
        job_id: number;
        job_title: string;
        total_candidates: number;
        algorithm: string;
        ranked_candidates: RankedCandidate[];
      }>(`/api/rankings/${jobId}`, { method: 'GET' });
    }
  },

  admin: {
    getDashboard: async () => {
      return safeApiCall<{
        admin: AdminProfile;
        stats: {
          total_students: number;
          placed_students: number;
          placement_percentage: number;
          highest_package: number;
          average_package: number | string;
          total_companies: number;
          total_jobs: number;
          total_applications: number;
          active_sessions: number;
        };
        students: StudentProfile[];
        companies: CompanyProfile[];
        jobs: JobDrive[];
        applications: Application[];
        recent_logs: Array<{ id: number; user_id: number; email: string; action: string; timestamp: string; details?: string }>;
      }>('/api/admin/dashboard', { method: 'GET' });
    },

    updateProfile: async (data: Partial<AdminProfile>) => {
      return safeApiCall<AdminProfile>('/api/admin/profile', {
        method: 'PUT',
        body: JSON.stringify(data)
      });
    },

    getBipartiteMatching: async () => {
      return safeApiCall<{
        algorithm: string;
        total_matches: number;
        allocation_rate: string;
        allocations: Array<{
          student_id: number;
          student_name: string;
          cgpa: number;
          allocated_job_id: number;
          job_title: string;
          company_name: string;
          package_lpa: number;
        }>;
      }>('/api/ads/bipartite-matching', { method: 'GET' });
    },

    searchSkills: async (query: string) => {
      return safeApiCall<{
        query: string;
        matches: string[];
        total_indexed: number;
      }>(`/api/ads/skill-trie?q=${encodeURIComponent(query)}`, { method: 'GET' });
    },

    getDemoAccounts: async () => {
      return safeApiCall<Array<{
        role: UserRole;
        email: string;
        password: string;
        name: string;
        description: string;
      }>>('/api/demo-accounts', { method: 'GET' });
    },

    resetDatabase: async () => {
      return safeApiCall('/api/reset-data', { method: 'POST' });
    }
  },

  debug: {
    testJsonSafeguard: async (testCase?: string) => {
      return safeApiCall<{ timestamp: string; received: any }>('/api/debug/test-json-safeguard', {
        method: 'POST',
        body: JSON.stringify({ test_case: testCase })
      });
    }
  }
};
