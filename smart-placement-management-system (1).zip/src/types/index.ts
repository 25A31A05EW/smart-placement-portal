export type UserRole = 'student' | 'company' | 'admin';

export interface User {
  id: number;
  email: string;
  role: UserRole;
  name: string;
  created_at: string;
}

export interface StudentProfile {
  user_id: number;
  name: string;
  email: string;
  phone: string;
  branch: string;
  semester: number;
  cgpa: number;
  skills: string[];
  academic_info: {
    tenth_percentage: number;
    twelfth_percentage: number;
    backlogs: number;
    bio: string;
  };
  resume_url?: string;
  updated_at: string;
}

export interface CompanyProfile {
  user_id: number;
  company_name: string;
  email: string;
  phone: string;
  website: string;
  location: string;
  industry: string;
  description: string;
  updated_at: string;
}

export interface AdminProfile {
  user_id: number;
  name: string;
  email: string;
  designation: string;
  department: string;
  phone: string;
  updated_at: string;
}

export interface JobDrive {
  id: number;
  company_id: number;
  company_name: string;
  title: string;
  role: string;
  package_lpa: number;
  cgpa_cutoff: number;
  eligible_branches: string[];
  required_skills: string[];
  location: string;
  deadline: string;
  description: string;
  status: 'active' | 'closed';
  created_at: string;
}

export type ApplicationStatus = 'applied' | 'shortlisted' | 'interview' | 'offered' | 'rejected';

export interface Application {
  id: number;
  job_id: number;
  student_id: number;
  student_name: string;
  student_branch: string;
  student_cgpa: number;
  student_skills: string[];
  job_title?: string;
  company_name?: string;
  package_lpa?: number;
  status: ApplicationStatus;
  applied_at: string;
  updated_at: string;
  composite_score?: number;
  notes?: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data: T | null;
}

export interface RankedCandidate {
  student_id: number;
  student_name: string;
  branch: string;
  cgpa: number;
  matched_skills: string[];
  missing_skills: string[];
  composite_score: number;
  rank: number;
  status: ApplicationStatus;
  application_id: number;
}
